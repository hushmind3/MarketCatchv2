#!/usr/bin/env python3
"""Local-only API bridge for the K-stock mobile prototype.

The server binds to 127.0.0.1, serves outputs/index.html, and proxies API calls
so credentials are never embedded in the HTML bundle. Secrets are accepted for
one request and are not written to disk or included in logs.
"""

from __future__ import annotations

import hashlib
import html
import io
import json
import re
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "outputs"
HOST = "127.0.0.1"
DEFAULT_PORT = 4173
# Android's bundled Python does not include the operating system IANA timezone
# database. Korea has used UTC+9 without daylight saving since 1988, so a fixed
# offset is both accurate for the app's market dates and safe on Android.
KST = timezone(timedelta(hours=9), name="KST")
MAX_BODY = 96 * 1024
ALLOWED_ORIGINS = {
    f"http://{HOST}:{DEFAULT_PORT}",
    f"http://localhost:{DEFAULT_PORT}",
}
SSL_CONTEXT = ssl.create_default_context()
CORP_CACHE: dict[str, list[dict[str, str]]] = {}
KIS_TOKEN_CACHE: dict[str, dict[str, Any]] = {}
KIS_TOKEN_LOCK = threading.Lock()
KIS_QUOTE_CACHE: dict[tuple[str, str], dict[str, Any]] = {}
KIS_BASELINE_CACHE: dict[tuple[str, str, str], dict[str, Any]] = {}
KIS_DATA_CACHE_LOCK = threading.Lock()
NAVER_QUERY_CACHE: dict[str, dict[str, Any]] = {}
NAVER_QUERY_CACHE_LOCK = threading.Lock()
DART_SCAN_CACHE: dict[str, dict[str, Any]] = {}
DART_SCAN_CACHE_LOCK = threading.Lock()

NAVER_SCAN_QUERIES = (
    "코스피 코스닥 증시 특징주 속보",
    "상장사 투자 인수 합병 최대주주",
    "정부 정책 규제 관세 환율 유가",
    "국부펀드 한국 기업 공급망 MOU",
    "반도체 AI 데이터센터 전력망",
    "배터리 전기차 리튬 니켈",
    "바이오 임상 허가 기술수출",
    "방산 조선 원전 로봇 수주",
    "희토류 핵심광물 공급망",
    "항공 여행 해운 물류 화장품 엔터 게임 우주",
    "급등 급락 이유",
)


EVENT_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("실적·전망 변화", ("잠정실적", "영업이익", "매출액", "실적", "전망 상향", "전망 하향", "어닝")),
    ("증자·감자·CB/BW", ("유상증자", "무상증자", "감자", "전환사채", "신주인수권", "채무증권", "사채권발행", "사채 발행", "cb", "bw")),
    ("지분·M&A·최대주주", ("인수", "합병", "m&a", "최대주주 변경", "경영권", "지분 취득", "지분투자")),
    ("계약 체결·해지", ("공급계약", "수주", "계약 체결", "계약 해지", "계약 종료", "납품")),
    ("임상·허가·실패", ("임상", "품목허가", "승인", "허가", "주요 지표 미충족", "시험 실패")),
    ("소송·제재·조사", ("소송", "기소", "과징금", "제재", "압수수색", "조사 착수", "상장폐지")),
    ("국가 협력·공급망", ("mou", "양해각서", "공급망 협력", "핵심광물 협력", "정상회담", "경제협력")),
    ("정책·환율·원자재", ("정부", "정책", "규제", "환율", "원달러", "유가", "원자재", "관세")),
    ("투자·자금 유입", ("국부펀드", "기관투자", "투자 유치", "투자 검토", "출자", "블랙록", "테마섹", "gic")),
]

# A ranking aid, not a price target.  A bare disclosure title cannot receive a
# high score only because it contains a positive-sounding keyword.  In
# particular, contract disclosures stay low until size/materiality is known.
IMPACT_POINTS = {
    "지분·M&A·최대주주": 38,
    "임상·허가·실패": 36,
    "실적·전망 변화": 34,
    "증자·감자·CB/BW": 33,
    "소송·제재·조사": 31,
    "투자·자금 유입": 29,
    "정책·환율·원자재": 27,
    "국가 협력·공급망": 24,
    "계약 체결·해지": 14,
    "기타": 8,
}

IMPACT_BOOST_WORDS = (
    "최대주주 변경", "합병", "경영권", "상장폐지", "유상증자", "감자",
    "흑자전환", "적자전환", "전망 상향", "전망 하향", "시험 실패",
    "주요 지표 미충족", "품목허가", "압수수색",
)

ROUTINE_DART = (
    "사업보고서", "반기보고서", "분기보고서", "임원ㆍ주요주주특정증권등소유상황보고서",
    "주식등의대량보유상황보고서", "증권발행실적보고서", "의결권대리행사권유참고서류",
)

KNOWN_COMPANIES = {
    "삼성전자": ("005930", "kospi", ("삼성전자",)),
    "SK하이닉스": ("000660", "kospi", ("SK하이닉스", "에스케이하이닉스", "SK hynix")),
    "현대차": ("005380", "kospi", ("현대차", "현대자동차")),
    "기아": ("000270", "kospi", ("기아", "기아차")),
    "NAVER": ("035420", "kospi", ("NAVER", "네이버")),
    "카카오": ("035720", "kospi", ("카카오",)),
    "한화에어로스페이스": ("012450", "kospi", ("한화에어로스페이스",)),
    "두산에너빌리티": ("034020", "kospi", ("두산에너빌리티",)),
    "삼성바이오로직스": ("207940", "kospi", ("삼성바이오로직스",)),
    "셀트리온": ("068270", "kospi", ("셀트리온",)),
    "에코프로비엠": ("247540", "kosdaq", ("에코프로비엠",)),
    "HLB": ("028300", "kosdaq", ("HLB", "에이치엘비")),
}

# Industry news often matters before a Korean company is named. Each tuple is
# (name, code, market, short role, factual connection, tier). Tier 1 is a core
# product/value-chain connection and tier 2 is a wider same-industry connection.
# These are inspection candidates, never automatic buy recommendations.
INDUSTRY_TOPICS: list[dict[str, Any]] = [
    {"topic": "HBM", "keywords": ("hbm", "고대역폭메모리"), "stocks": (
        ("SK하이닉스", "000660", "kospi", "HBM", "HBM 메모리 주요 생산사", 1),
        ("삼성전자", "005930", "kospi", "HBM", "HBM 메모리 생산사", 1),
        ("한미반도체", "042700", "kospi", "TC본더", "HBM용 TC본더 장비 사업", 1),
        ("ISC", "095340", "kosdaq", "테스트", "AI·메모리 반도체 테스트 소켓 사업", 1),
        ("테크윙", "089030", "kosdaq", "검사장비", "메모리 반도체 검사 장비 사업", 1),
        ("디아이", "003160", "kospi", "검사장비", "메모리 반도체 검사 장비 사업", 2),
    )},
    {"topic": "반도체 장비·소재", "keywords": ("반도체 장비", "반도체장비", "웨이퍼 장비", "반도체 공정", "후공정", "첨단 패키징"), "stocks": (
        ("한미반도체", "042700", "kospi", "후공정", "반도체 후공정 장비 사업", 1),
        ("원익IPS", "240810", "kosdaq", "증착장비", "반도체 증착 장비 사업", 1),
        ("HPSP", "403870", "kosdaq", "어닐링", "반도체 고압 수소 어닐링 장비 사업", 1),
        ("주성엔지니어링", "036930", "kosdaq", "증착장비", "반도체 증착 장비 사업", 1),
        ("PSK", "319660", "kosdaq", "세정장비", "반도체 세정·감광액 제거 장비 사업", 1),
        ("유진테크", "084370", "kosdaq", "증착장비", "반도체 증착 장비 사업", 1),
        ("테스", "095610", "kosdaq", "공정장비", "반도체 전공정 장비 사업", 1),
        ("리노공업", "058470", "kosdaq", "검사부품", "반도체 검사 소켓·핀 사업", 2),
        ("하나마이크론", "067310", "kosdaq", "패키징", "반도체 패키징·테스트 사업", 2),
        ("SFA반도체", "036540", "kosdaq", "패키징", "반도체 패키징·테스트 사업", 2),
    )},
    {"topic": "반도체", "keywords": ("반도체", "메모리칩", "메모리 반도체", "파운드리", "dram", "낸드", "nand"), "stocks": (
        ("삼성전자", "005930", "kospi", "메모리·파운드리", "메모리·파운드리 핵심 사업", 1),
        ("SK하이닉스", "000660", "kospi", "메모리", "메모리 반도체 핵심 사업", 1),
        ("한미반도체", "042700", "kospi", "후공정", "반도체 후공정 장비 사업", 1),
        ("원익IPS", "240810", "kosdaq", "전공정", "반도체 전공정 장비 사업", 1),
        ("HPSP", "403870", "kosdaq", "공정장비", "반도체 공정 장비 사업", 2),
        ("리노공업", "058470", "kosdaq", "검사부품", "반도체 검사 부품 사업", 2),
        ("하나마이크론", "067310", "kosdaq", "패키징", "반도체 패키징·테스트 사업", 2),
    )},
    {"topic": "전력망·변압기", "keywords": ("전력망", "변압기", "전력기기", "송배전", "데이터센터 전력"), "stocks": (
        ("HD현대일렉트릭", "267260", "kospi", "변압기", "변압기·전력기기 주력", 1),
        ("LS ELECTRIC", "010120", "kospi", "배전", "배전·전력 자동화 사업", 1),
        ("효성중공업", "298040", "kospi", "초고압", "초고압 변압기 사업", 1),
        ("일진전기", "103590", "kospi", "전선·변압기", "전선·변압기 사업", 1),
        ("제룡전기", "033100", "kosdaq", "변압기", "배전 변압기 사업", 1),
        ("산일전기", "062040", "kospi", "특수변압기", "특수 변압기 사업", 1),
        ("대한전선", "001440", "kospi", "전력케이블", "전력 케이블 사업", 2),
        ("가온전선", "000500", "kospi", "전력케이블", "전력 케이블 사업", 2),
    )},
    {"topic": "원전", "keywords": ("원전", "원자력발전", "원자력 발전", "smr", "소형모듈원자로"), "stocks": (
        ("두산에너빌리티", "034020", "kospi", "주기기", "원전 주기기·SMR 사업", 1),
        ("한전기술", "052690", "kospi", "설계", "원전 설계 사업", 1),
        ("한전KPS", "051600", "kospi", "정비", "원전 정비 사업", 1),
        ("비에이치아이", "083650", "kosdaq", "발전설비", "발전 설비 사업", 1),
        ("우리기술", "032820", "kosdaq", "제어시스템", "원전 제어 시스템 사업", 2),
        ("우진", "105840", "kospi", "계측기", "원전 계측기 사업", 2),
        ("보성파워텍", "006910", "kosdaq", "철구조물", "전력·원전 철구조물 사업", 2),
        ("일진파워", "094820", "kosdaq", "정비", "발전소 정비 사업", 2),
    )},
    {"topic": "방산", "keywords": ("방산", "무기 수출", "국방비", "미사일", "전차 수출", "전투기 수출"), "stocks": (
        ("한화에어로스페이스", "012450", "kospi", "지상무기", "항공엔진·지상 방산 사업", 1),
        ("LIG넥스원", "079550", "kospi", "유도무기", "유도무기·방공 체계 사업", 1),
        ("현대로템", "064350", "kospi", "전차", "전차·지상 무기 사업", 1),
        ("한국항공우주", "047810", "kospi", "군용기", "군용기·항공기 사업", 1),
        ("풍산", "103140", "kospi", "탄약", "방산용 탄약 사업", 2),
        ("SNT다이내믹스", "003570", "kospi", "구동장치", "방산 구동장치 사업", 2),
        ("퍼스텍", "010820", "kospi", "항공부품", "방산·항공 부품 사업", 2),
    )},
    {"topic": "2차전지", "keywords": ("2차전지", "이차전지", "배터리", "양극재", "전기차 배터리"), "stocks": (
        ("LG에너지솔루션", "373220", "kospi", "셀", "전기차 배터리 생산", 1),
        ("삼성SDI", "006400", "kospi", "셀", "전기차·ESS 배터리 생산", 1),
        ("SK이노베이션", "096770", "kospi", "셀", "배터리 자회사 사업", 1),
        ("LG화학", "051910", "kospi", "소재", "배터리 소재 사업", 1),
        ("에코프로비엠", "247540", "kosdaq", "양극재", "배터리 양극재 사업", 1),
        ("포스코퓨처엠", "003670", "kospi", "양·음극재", "배터리 양·음극재 사업", 1),
        ("엘앤에프", "066970", "kosdaq", "양극재", "배터리 양극재 사업", 1),
        ("대주전자재료", "078600", "kosdaq", "음극재", "실리콘 음극재 사업", 2),
        ("엔켐", "348370", "kosdaq", "전해액", "배터리 전해액 사업", 2),
        ("천보", "278280", "kosdaq", "전해질", "배터리 전해질 소재 사업", 2),
        ("SK아이이테크놀로지", "361610", "kospi", "분리막", "배터리 분리막 사업", 2),
        ("성일하이텍", "365340", "kosdaq", "재활용", "폐배터리 재활용 사업", 2),
    )},
    {"topic": "조선", "keywords": ("조선", "조선업", "선박 수주", "lng선", "컨테이너선", "유조선"), "stocks": (
        ("HD한국조선해양", "009540", "kospi", "조선", "조선 중간지주·선박 사업", 1),
        ("HD현대중공업", "329180", "kospi", "대형선", "대형 선박·엔진 사업", 1),
        ("HD현대미포", "010620", "kospi", "중형선", "중형 선박 사업", 1),
        ("한화오션", "042660", "kospi", "LNG·특수선", "LNG선·특수선 사업", 1),
        ("삼성중공업", "010140", "kospi", "LNG·해양", "LNG선·해양플랜트 사업", 1),
        ("동성화인텍", "033500", "kosdaq", "보냉재", "LNG선 보냉재 사업", 2),
        ("한국카본", "017960", "kospi", "보냉재", "LNG선 보냉재 사업", 2),
        ("성광벤드", "014620", "kosdaq", "피팅", "조선·플랜트용 관이음쇠 사업", 2),
    )},
    {"topic": "로봇", "keywords": ("로봇", "휴머노이드", "산업용 로봇", "협동로봇", "로봇 산업"), "stocks": (
        ("두산로보틱스", "454910", "kospi", "협동로봇", "협동로봇 사업", 1),
        ("레인보우로보틱스", "277810", "kosdaq", "휴머노이드", "휴머노이드·로봇 플랫폼 사업", 1),
        ("로보티즈", "108490", "kosdaq", "액추에이터", "로봇 액추에이터·서비스로봇 사업", 1),
        ("에스피지", "058610", "kosdaq", "감속기", "로봇용 정밀 감속기 사업", 1),
        ("로보스타", "090360", "kosdaq", "산업로봇", "산업용 로봇 사업", 2),
    )},
    {"topic": "희토류·영구자석", "keywords": (
        "희토류", "희토류 정제", "희토류 제련", "영구자석", "네오디뮴", "rare earth", "permanent magnet",
    ), "stocks": (
        ("고려아연", "010130", "kospi", "정제 확대", "핵심광물 재활용 사업을 희토류까지 확대할 계획", 1),
        ("LS에코에너지", "229640", "kospi", "금속화", "베트남 희토류 금속화 사업 추진", 1),
        ("포스코인터내셔널", "047050", "kospi", "영구자석", "희토류 영구자석 공급망·공급 계약", 1),
        ("노바텍", "285490", "kosdaq", "네오디뮴 자석", "네오디뮴 영구자석 응용·가공 사업", 1),
        ("유니온머티리얼", "047400", "kospi", "대체 자석", "희토류를 쓰지 않는 페라이트 마그네트 사업", 2),
    )},
    {"topic": "AI·데이터센터", "keywords": ("인공지능", "생성형 ai", "ai 투자", "ai 데이터센터", "데이터센터", "ai 인프라", "gpu 서버"), "stocks": (
        ("SK하이닉스", "000660", "kospi", "AI 메모리", "AI 서버용 메모리 사업", 1),
        ("삼성전자", "005930", "kospi", "AI 메모리", "AI 서버용 메모리·반도체 사업", 1),
        ("한미반도체", "042700", "kospi", "HBM 장비", "HBM 후공정 장비 사업", 1),
        ("HD현대일렉트릭", "267260", "kospi", "전력기기", "데이터센터 전력 설비와 연결", 2),
        ("LS ELECTRIC", "010120", "kospi", "배전", "데이터센터 배전 설비와 연결", 2),
        ("효성중공업", "298040", "kospi", "변압기", "데이터센터 전력 설비와 연결", 2),
        ("GST", "083450", "kosdaq", "냉각", "반도체·데이터센터 냉각 기술 사업", 2),
        ("케이엔솔", "053080", "kosdaq", "냉각", "데이터센터 냉각 솔루션 사업", 2),
    )},
    {"topic": "바이오·기술수출", "keywords": ("바이오", "기술수출", "기술 이전", "신약", "임상시험", "바이오시밀러", "품목허가"), "stocks": (
        ("삼성바이오로직스", "207940", "kospi", "위탁생산", "바이오의약품 위탁개발생산 사업", 1),
        ("셀트리온", "068270", "kospi", "바이오시밀러", "바이오시밀러 개발·판매", 1),
        ("SK바이오팜", "326030", "kospi", "신약", "신약 개발·판매", 1),
        ("알테오젠", "196170", "kosdaq", "약물전달", "바이오의약품 제형 기술 사업", 1),
        ("유한양행", "000100", "kospi", "신약", "신약 개발·기술수출 사업", 1),
        ("HLB", "028300", "kosdaq", "항암제", "항암 신약 개발 사업", 2),
    )},
    {"topic": "자동차·전기차", "keywords": ("자동차", "전기차", "ev 판매", "차량용", "자율주행"), "stocks": (
        ("현대차", "005380", "kospi", "완성차", "완성차·전기차 사업", 1),
        ("기아", "000270", "kospi", "완성차", "완성차·전기차 사업", 1),
        ("현대모비스", "012330", "kospi", "핵심부품", "자동차 핵심 부품 사업", 1),
        ("HL만도", "204320", "kospi", "제동·조향", "자동차 제동·조향 부품 사업", 2),
    )},
    {"topic": "수소", "keywords": ("수소", "수소경제", "수소 발전", "연료전지", "수소차", "그린수소"), "stocks": (
        ("두산퓨얼셀", "336260", "kospi", "연료전지", "발전용 연료전지 사업", 1),
        ("범한퓨얼셀", "382900", "kosdaq", "연료전지", "수소 연료전지 사업", 1),
        ("일진하이솔루스", "271940", "kospi", "수소탱크", "수소 저장용기 사업", 1),
        ("효성중공업", "298040", "kospi", "충전소", "수소 충전 인프라 사업", 2),
    )},
    {"topic": "태양광", "keywords": ("태양광", "태양전지", "태양광 모듈", "폴리실리콘"), "stocks": (
        ("한화솔루션", "009830", "kospi", "모듈", "태양광 셀·모듈 사업", 1),
        ("OCI홀딩스", "010060", "kospi", "폴리실리콘", "태양광용 폴리실리콘 사업", 1),
        ("HD현대에너지솔루션", "322000", "kospi", "모듈", "태양광 모듈·시스템 사업", 1),
        ("신성이엔지", "011930", "kospi", "모듈", "태양광 모듈 사업", 2),
    )},
    {"topic": "화장품", "keywords": ("화장품", "k뷰티", "k-뷰티", "뷰티 수출"), "stocks": (
        ("아모레퍼시픽", "090430", "kospi", "브랜드", "화장품 브랜드 사업", 1),
        ("LG생활건강", "051900", "kospi", "브랜드", "화장품 브랜드 사업", 1),
        ("코스맥스", "192820", "kospi", "ODM", "화장품 ODM 사업", 1),
        ("한국콜마", "161890", "kospi", "ODM", "화장품 ODM 사업", 1),
        ("실리콘투", "257720", "kosdaq", "유통", "K뷰티 해외 유통 사업", 2),
        ("펌텍코리아", "251970", "kosdaq", "용기", "화장품 용기 사업", 2),
    )},
    {"topic": "엔터테인먼트", "keywords": ("k팝", "k-pop", "음반 판매", "월드투어", "엔터테인먼트", "엔터주"), "stocks": (
        ("HYBE", "352820", "kospi", "음악·공연", "아티스트·음악·공연 사업", 1),
        ("에스엠", "041510", "kosdaq", "음악·공연", "아티스트·음악·공연 사업", 1),
        ("JYP Ent.", "035900", "kosdaq", "음악·공연", "아티스트·음악·공연 사업", 1),
        ("와이지엔터테인먼트", "122870", "kosdaq", "음악·공연", "아티스트·음악·공연 사업", 1),
        ("스튜디오드래곤", "253450", "kosdaq", "콘텐츠", "영상 콘텐츠 제작 사업", 2),
    )},
    {"topic": "항공·여행", "keywords": ("항공사", "항공주", "항공 운임", "여행업", "여행주", "여행 수요", "해외여행", "국제선 여객", "원화 강세", "환율 급락"), "stocks": (
        ("대한항공", "003490", "kospi", "항공", "국제선 여객·화물 사업", 1),
        ("제주항공", "089590", "kospi", "저비용항공", "국제선 여객 사업", 1),
        ("진에어", "272450", "kospi", "저비용항공", "국제선 여객 사업", 1),
        ("티웨이항공", "091810", "kospi", "저비용항공", "국제선 여객 사업", 1),
        ("하나투어", "039130", "kospi", "해외여행", "해외여행 상품 사업", 2),
        ("모두투어", "080160", "kosdaq", "해외여행", "해외여행 상품 사업", 2),
    )},
    {"topic": "해운·물류", "keywords": ("해운", "운임", "물류대란", "컨테이너 운임", "홍해"), "stocks": (
        ("HMM", "011200", "kospi", "컨테이너", "컨테이너 해운 사업", 1),
        ("팬오션", "028670", "kospi", "벌크선", "벌크 해운 사업", 1),
        ("대한해운", "005880", "kospi", "벌크선", "벌크 해운 사업", 1),
    )},
    {"topic": "게임", "keywords": ("게임", "게임 신작", "게임 출시", "게임 규제", "콘솔 게임", "모바일 게임"), "stocks": (
        ("크래프톤", "259960", "kospi", "게임", "게임 개발·서비스 사업", 1),
        ("엔씨소프트", "036570", "kospi", "게임", "게임 개발·서비스 사업", 1),
        ("넷마블", "251270", "kospi", "게임", "게임 개발·서비스 사업", 1),
        ("펄어비스", "263750", "kosdaq", "게임", "게임 개발·서비스 사업", 1),
    )},
    {"topic": "우주·위성", "keywords": ("우주항공", "우주 산업", "위성 발사", "발사체", "저궤도 위성"), "stocks": (
        ("한국항공우주", "047810", "kospi", "항공우주", "항공기·우주 사업", 1),
        ("한화에어로스페이스", "012450", "kospi", "발사체", "우주 발사체 엔진 사업", 1),
        ("쎄트렉아이", "099320", "kosdaq", "위성", "위성 시스템 사업", 1),
        ("AP위성", "211270", "kosdaq", "위성통신", "위성통신 단말 사업", 2),
    )},
]

BAD_NEWS_WORDS = (
    "유상증자", "감자 결정", "전환사채권발행결정", "신주인수권부사채권발행결정",
    "채무증권발행결정", "계약 해지", "계약해지", "계약 취소", "수주 취소",
    "전망 하향", "실적 하향", "매출 감소", "영업이익 감소", "순이익 감소",
    "적자전환", "영업손실", "상장폐지", "관리종목", "횡령", "배임", "압수수색",
    "과징금", "제재", "기소", "조사 착수", "소송 제기", "소송등의제기", "경영권분쟁소송",
    "임상 실패", "시험 실패",
    "임상 중단", "주요 지표 미충족", "허가 취소", "승인 취소", "허가 반려",
    "리콜", "부도", "파산", "회생절차", "생산 중단", "거래 정지",
)
GOOD_NEWS_WORDS = (
    "흑자전환", "전망 상향", "실적 상향", "사상 최대 실적", "품목허가 승인",
    "허가 승인", "임상 성공", "임상 진입", "목표 달성", "대규모 수주", "수주",
    "공급계약 체결", "계약 체결", "기술수출", "투자 유치", "투자유치", "지분 투자",
    "전략적 투자", "인수", "합병", "업무협약", "양해각서", "mou", "공급망 협력",
    "특허 취득", "사업자 선정", "우선협상대상자", "낙찰", "자사주 소각", "배당 확대",
    "무상증자", "발행후만기전사채취득", "성장", "증설", "생산 확대",
)
DIFFERENT_BY_STOCK_WORDS = ("환율", "원달러", "유가", "금리", "관세", "원자재 가격", "정부 규제")


class ApiProblem(RuntimeError):
    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.status = status


def clean_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html.unescape(value or ""))).strip()


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return default


def now_kst() -> datetime:
    return datetime.now(KST)


def previous_weekday(value: datetime) -> datetime:
    day = value - timedelta(days=1)
    while day.weekday() >= 5:
        day -= timedelta(days=1)
    return day


def scan_start(window: str) -> datetime:
    now = now_kst()
    if window == "3h":
        return now - timedelta(hours=3)
    if window == "6h":
        return now - timedelta(hours=6)
    if window == "24h":
        return now - timedelta(hours=24)
    if window == "today":
        return now.replace(hour=0, minute=0, second=0, microsecond=0)
    if window == "7d":
        return now - timedelta(days=7)
    if window == "30d":
        return now - timedelta(days=30)
    if window == "90d":
        return now - timedelta(days=90)
    prior = previous_weekday(now)
    return prior.replace(hour=15, minute=30, second=0, microsecond=0)


def search_terms(body: dict[str, Any]) -> list[str]:
    """Comma/newline separated terms are OR conditions, capped for API safety."""
    raw = str(body.get("searchKeyword", ""))
    terms = [clean_text(term) for term in re.split(r"[,\n]+", raw)]
    return list(dict.fromkeys(term for term in terms if term))[:5]


def text_matches_terms(text: str, terms: list[str]) -> bool:
    if not terms:
        return True
    lowered = text.lower()
    compact = re.sub(r"[\W_]+", "", lowered)
    return any(
        term.lower() in lowered or re.sub(r"[\W_]+", "", term.lower()) in compact
        for term in terms
    )


def parse_news_date(value: str) -> datetime:
    try:
        parsed = parsedate_to_datetime(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=KST)
        return parsed.astimezone(KST)
    except (TypeError, ValueError, OverflowError):
        return now_kst()


def parse_iso_date(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=KST)
        return parsed.astimezone(KST)
    except (TypeError, ValueError, OverflowError):
        return now_kst()


def display_time(value: datetime) -> str:
    now = now_kst()
    if value.date() == now.date():
        return value.strftime("오늘 %H:%M")
    if value.date() == (now - timedelta(days=1)).date():
        return value.strftime("어제 %H:%M")
    return value.strftime("%m월 %d일 %H:%M")


def request_bytes(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | None = None,
    payload: dict[str, Any] | None = None,
    timeout: int = 20,
) -> bytes:
    if params:
        query = urllib.parse.urlencode(params)
        url = f"{url}{'&' if '?' in url else '?'}{query}"
    data = None
    req_headers = {"User-Agent": "MarketCatch/2.0.2", **(headers or {})}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req_headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=req_headers, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=SSL_CONTEXT) as response:
            return response.read()
    except urllib.error.HTTPError as error:
        raw = error.read().decode("utf-8", "replace")[:600]
        try:
            parsed = json.loads(raw)
            detail = parsed.get("errorMessage") or parsed.get("message") or parsed.get("msg1") or parsed.get("error", {}).get("message")
        except (json.JSONDecodeError, AttributeError):
            detail = None
        raise ApiProblem(detail or f"외부 API가 HTTP {error.code}을 반환했습니다", 502) from error
    except urllib.error.URLError as error:
        raise ApiProblem(f"외부 API 연결 실패: {getattr(error, 'reason', error)}", 502) from error


def request_json(url: str, **kwargs: Any) -> dict[str, Any]:
    raw = request_bytes(url, **kwargs)
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ApiProblem("외부 API 응답이 JSON 형식이 아닙니다") from error
    if not isinstance(data, dict):
        raise ApiProblem("외부 API 응답 형식이 예상과 다릅니다")
    return data


def naver_config(body: dict[str, Any]) -> tuple[str, dict[str, str]]:
    client_id = str(body.get("naverId", "")).strip()
    secret = str(body.get("naverSecret", "")).strip()
    if not client_id or not secret:
        raise ApiProblem("NAVER API HUB Client ID와 Client Secret을 모두 입력하세요", 400)
    mode = body.get("naverMode", "hub")
    if mode == "legacy":
        return "https://openapi.naver.com/v1/search/news.json", {
            "X-Naver-Client-Id": client_id,
            "X-Naver-Client-Secret": secret,
        }
    return "https://naverapihub.apigw.ntruss.com/search/v1/news", {
        "X-NCP-APIGW-API-KEY-ID": client_id,
        "X-NCP-APIGW-API-KEY": secret,
    }


def fetch_naver(body: dict[str, Any], query: str, display: int = 50) -> list[dict[str, Any]]:
    url, headers = naver_config(body)
    data = request_json(url, headers=headers, params={"query": query, "display": display, "start": 1, "sort": "date"})
    items: list[dict[str, Any]] = []
    for entry in data.get("items", []):
        if not isinstance(entry, dict):
            continue
        published = parse_news_date(str(entry.get("pubDate", "")))
        link = str(entry.get("originallink") or entry.get("link") or "")
        items.append({
            "title": clean_text(str(entry.get("title", ""))),
            "summary": clean_text(str(entry.get("description", ""))),
            "link": link,
            "published": published,
            "time_known": True,
            "source": urllib.parse.urlparse(link).netloc.replace("www.", "") or "네이버 뉴스",
            "official": False,
            "company": "",
            "stock_code": "",
            "market": "",
        })
    return items


def fetch_naver_cached(body: dict[str, Any], query: str, display: int = 50) -> tuple[list[dict[str, Any]], bool]:
    """Reuse a very recent identical query so repeated manual scans return quickly."""
    identity = "\0".join((
        str(body.get("naverMode", "hub")),
        str(body.get("naverId", "")).strip(),
        str(body.get("naverSecret", "")).strip(),
        query,
        str(display),
    ))
    cache_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    now = time.time()
    with NAVER_QUERY_CACHE_LOCK:
        cached = NAVER_QUERY_CACHE.get(cache_key, {})
        if now - safe_float(cached.get("fetched_at"), 0) <= 20:
            return list(cached.get("items", [])), True
    try:
        items = fetch_naver(body, query, display)
    except ApiProblem as error:
        message = str(error).lower()
        if "rate limit" not in message and "속도 제한" not in message and error.status < 500:
            raise
        time.sleep(0.8)
        items = fetch_naver(body, query, display)
    with NAVER_QUERY_CACHE_LOCK:
        NAVER_QUERY_CACHE[cache_key] = {"items": list(items), "fetched_at": time.time()}
    return items, False


def fetch_naver_scan(body: dict[str, Any], start: datetime) -> tuple[list[dict[str, Any]], list[str], int]:
    """Run the broad market-news queries concurrently and keep partial successes."""
    collected: list[dict[str, Any]] = []
    errors: list[str] = []
    cached_queries = 0
    queries = search_terms(body) if body.get("scanMode") == "keyword" else list(NAVER_SCAN_QUERIES)
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix="naver-news") as executor:
        futures = [executor.submit(fetch_naver_cached, body, query, 50) for query in queries]
        for query, future in zip(queries, futures):
            try:
                items, cached = future.result()
                collected.extend(items)
                cached_queries += int(cached)
            except ApiProblem as error:
                errors.append(f"{query}: {error}")
    recent = [item for item in collected if item["published"] >= start]
    return recent, errors, cached_queries


GLOBAL_NEWS_TERMS = (
    "korea", "korean", "samsung", "sk hynix", "hbm", "semiconductor", "memory chip",
    "battery", "nuclear", "shipbuilding", "defense", "tariff", "oil price", "rare earth",
    "critical mineral", "permanent magnet", "supply chain", "sovereign wealth fund", "temasek", "gic",
)


def global_news_item(title: str, summary: str, link: str, published: datetime, source: str) -> dict[str, Any]:
    return {
        "title": clean_text(title), "summary": clean_text(summary), "link": link,
        "published": published, "time_known": True, "source": clean_text(source) or "해외 뉴스",
        "official": False, "company": "", "stock_code": "", "market": "",
    }


def fetch_global_news(body: dict[str, Any], start: datetime) -> list[dict[str, Any]]:
    service = str(body.get("globalService", "finnhub"))
    key = str(body.get("globalKey", "")).strip()
    if not key:
        return []
    items: list[dict[str, Any]] = []
    if service == "finnhub":
        raw = request_bytes("https://finnhub.io/api/v1/news", params={"category": "general", "token": key})
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ApiProblem("Finnhub 응답을 읽지 못했습니다") from error
        if not isinstance(data, list):
            raise ApiProblem("Finnhub API Key 또는 응답 형식을 확인하세요")
        for entry in data:
            if not isinstance(entry, dict):
                continue
            title = clean_text(str(entry.get("headline", "")))
            summary = clean_text(str(entry.get("summary", "")))
            searchable = f"{title} {summary}".lower()
            if not any(term in searchable for term in GLOBAL_NEWS_TERMS):
                continue
            published = datetime.fromtimestamp(safe_float(entry.get("datetime")), tz=KST)
            if published < start:
                continue
            items.append(global_news_item(title, summary, str(entry.get("url", "")), published, str(entry.get("source", "Finnhub"))))
    elif service == "newsapi":
        data = request_json("https://newsapi.org/v2/everything", params={
            "q": '(Korea OR Samsung OR "SK hynix" OR HBM OR semiconductor OR battery OR shipbuilding OR "rare earth" OR "critical minerals" OR "supply chain")',
            "language": "en", "sortBy": "publishedAt", "pageSize": 50,
            "from": start.isoformat(), "apiKey": key,
        })
        for entry in data.get("articles", []):
            if not isinstance(entry, dict):
                continue
            published = parse_iso_date(str(entry.get("publishedAt", "")))
            if published >= start:
                source = entry.get("source") if isinstance(entry.get("source"), dict) else {}
                items.append(global_news_item(str(entry.get("title", "")), str(entry.get("description", "")), str(entry.get("url", "")), published, str(source.get("name", "NewsAPI"))))
    elif service == "gnews":
        data = request_json("https://gnews.io/api/v4/search", params={
            "q": 'Korea OR Samsung OR "SK hynix" OR HBM OR semiconductor OR battery OR "rare earth" OR "critical minerals"',
            "lang": "en", "max": 10, "sortby": "publishedAt", "from": start.isoformat(), "apikey": key,
        })
        for entry in data.get("articles", []):
            if not isinstance(entry, dict):
                continue
            published = parse_iso_date(str(entry.get("publishedAt", "")))
            if published >= start:
                source = entry.get("source") if isinstance(entry.get("source"), dict) else {}
                items.append(global_news_item(str(entry.get("title", "")), str(entry.get("description", "")), str(entry.get("url", "")), published, str(source.get("name", "GNews"))))
    return items


def dart_key(body: dict[str, Any]) -> str:
    key = str(body.get("dartKey", "")).strip()
    if not key:
        raise ApiProblem("OpenDART 인증키를 입력하세요", 400)
    return key


def fetch_dart_time_map(
    start: datetime, corp_classes: list[str], target_days: set[str] | None = None,
) -> dict[str, datetime]:
    """Read exact filing times from DART's official recent-disclosure pages.

    OpenDART list.json intentionally exposes rcept_dt as YYYYMMDD only.  The
    public DART recent-disclosure pages expose HH:MM beside the same rcept_no,
    so matching on the receipt number avoids inventing a filing time.
    """
    endpoints = {"Y": "mainY.do", "K": "mainK.do"}
    work: list[tuple[datetime, str, str]] = []
    day = start.replace(hour=0, minute=0, second=0, microsecond=0)
    final_day = now_kst().replace(hour=0, minute=0, second=0, microsecond=0)
    while day <= final_day:
        if target_days is None or day.strftime("%Y%m%d") in target_days:
            for corp_class in corp_classes:
                endpoint = endpoints.get(corp_class)
                if endpoint:
                    work.append((day, corp_class, endpoint))
        day += timedelta(days=1)

    def fetch_day_market(job: tuple[datetime, str, str]) -> dict[str, datetime]:
        target_day, _corp_class, endpoint = job
        found: dict[str, datetime] = {}
        page_no = 1
        total_pages = 1
        while page_no <= total_pages and page_no <= 20:
            try:
                raw = request_bytes(
                    f"https://dart.fss.or.kr/dsac001/{endpoint}",
                    params={
                        "selectDate": target_day.strftime("%Y.%m.%d"),
                        "currentPage": page_no,
                        "maxResults": 100,
                    },
                    timeout=15,
                )
            except ApiProblem:
                break
            page = raw.decode("utf-8", "replace")
            for row in re.findall(r"<tr\b[^>]*>(.*?)</tr>", page, flags=re.I | re.S):
                receipt_match = re.search(r"rcpNo=(\d{14})", row)
                clock_match = re.search(r">\s*([0-2]\d:[0-5]\d)\s*</td>", row, flags=re.I)
                if not receipt_match or not clock_match:
                    continue
                hour, minute = (int(value) for value in clock_match.group(1).split(":"))
                found[receipt_match.group(1)] = target_day.replace(hour=hour, minute=minute)
            page_info = re.search(
                r'class=["\'][^"\']*\bpageInfo\b[^"\']*["\'][^>]*>.*?'
                r'\[\s*\d+\s*/\s*(\d+)\s*\]',
                page,
                flags=re.I | re.S,
            )
            total_pages = min(20, max(1, int(page_info.group(1)))) if page_info else 1
            page_no += 1
        return found

    mapping: dict[str, datetime] = {}
    if work:
        with ThreadPoolExecutor(max_workers=min(4, len(work)), thread_name_prefix="dart-times") as executor:
            for partial in executor.map(fetch_day_market, work):
                mapping.update(partial)
    return mapping


def fetch_dart(body: dict[str, Any], start: datetime) -> list[dict[str, Any]]:
    key = dart_key(body)
    terms = search_terms(body) if body.get("scanMode") == "keyword" else []
    corp_classes = [
        corp_class for corp_class, enabled in (
            ("Y", body.get("kospiEnabled", True)),
            ("K", body.get("kosdaqEnabled", True)),
        ) if enabled
    ]
    if not corp_classes:
        return []
    company_match: dict[str, str] | None = None
    if len(terms) == 1:
        try:
            company_match = next((
                company for company in get_corp_master(body)
                if terms[0].lower() in {company["name"].lower(), company["code"].lower()}
            ), None)
        except ApiProblem:
            company_match = None

    def fetch_corp_class(corp_class: str) -> list[dict[str, Any]]:
        class_entries: list[dict[str, Any]] = []
        page_no = 1
        while True:
            params = {
                "crtfc_key": key,
                "bgn_de": start.strftime("%Y%m%d"),
                "end_de": now_kst().strftime("%Y%m%d"),
                "corp_cls": corp_class,
                "page_no": page_no,
                "page_count": 100,
                "sort": "date",
                "sort_mth": "desc",
            }
            if company_match:
                params["corp_code"] = company_match["corp_code"]
            elif terms and any(classify_event(term) != "기타" for term in terms):
                # Most event-name searches (유상증자, 계약, 소송, M&A...) live
                # in significant-event filings. This cuts a 90-day scan down
                # before the local title filter runs.
                params["pblntf_ty"] = "B"
            data = request_json("https://opendart.fss.or.kr/api/list.json", params=params)
            status = str(data.get("status", ""))
            if status == "013":
                break
            if status != "000":
                raise ApiProblem(str(data.get("message") or f"OpenDART 오류 {status}"))
            class_entries.extend(entry for entry in data.get("list", []) if isinstance(entry, dict))
            total_pages = max(1, int(safe_float(data.get("total_page"), 1)))
            if page_no >= total_pages:
                break
            page_no += 1
        return class_entries

    def fetch_all_entries() -> list[dict[str, Any]]:
        found: list[dict[str, Any]] = []
        with ThreadPoolExecutor(max_workers=len(corp_classes), thread_name_prefix="dart-list") as executor:
            for class_entries in executor.map(fetch_corp_class, corp_classes):
                found.extend(class_entries)
        return found

    exact_times: dict[str, datetime] = {}
    if terms:
        entries = fetch_all_entries()
        if not company_match:
            entries = [
                entry for entry in entries
                if text_matches_terms(
                    f"{clean_text(str(entry.get('corp_name', '')))} {clean_text(str(entry.get('report_nm', '')))}",
                    terms,
                )
            ]
        # Old DART list results expose only the date. Exact HH:MM lookup is
        # limited to matched recent dates so a 3-month keyword search does not
        # crawl every market day merely to draw the timeline.
        recent_floor = (now_kst() - timedelta(days=7)).date()
        target_days = {
            str(entry.get("rcept_dt", "")) for entry in entries
            if str(entry.get("rcept_dt", "")) >= recent_floor.strftime("%Y%m%d")
        }
        try:
            exact_times = fetch_dart_time_map(start, corp_classes, target_days)
        except ApiProblem:
            exact_times = {}
    else:
        # The official API gives the filings while the public recent-disclosure
        # page gives their HH:MM receipt times. For short market scans, read
        # both independently at the same time.
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="dart-sources") as executor:
            times_future = executor.submit(fetch_dart_time_map, start, corp_classes)
            entries_future = executor.submit(fetch_all_entries)
            entries = entries_future.result()
            try:
                exact_times = times_future.result()
            except ApiProblem:
                exact_times = {}

    items: list[dict[str, Any]] = []
    for entry in entries:
        report = clean_text(str(entry.get("report_nm", "")))
        if any(word in report for word in ROUTINE_DART):
            continue
        date_text = str(entry.get("rcept_dt", ""))
        receipt = str(entry.get("rcept_no", ""))
        try:
            date_only = datetime.strptime(date_text, "%Y%m%d").replace(tzinfo=KST, hour=0, minute=0)
        except ValueError:
            date_only = now_kst().replace(hour=0, minute=0, second=0, microsecond=0)
        published = exact_times.get(receipt, date_only)
        time_known = receipt in exact_times
        if time_known and published < start:
            continue
        if not time_known and published.date() < start.date():
            continue
        company = clean_text(str(entry.get("corp_name", "")))
        corp_class = str(entry.get("corp_cls", ""))
        market = "kosdaq" if corp_class == "K" else "kospi" if corp_class == "Y" else ""
        items.append({
            "title": f"{company} · {report}" if company else report,
            "summary": f"{company} 제출 OpenDART 공식 공시입니다. 제목과 원문을 확인해 실제 숫자와 조건을 판단해야 합니다.",
            "link": f"https://dart.fss.or.kr/dsaf001/main.do?rcpNo={receipt}",
            "published": published,
            "time_known": time_known,
            "time_source": "DART 최근공시" if time_known else "OpenDART 접수일자",
            "source": "OpenDART",
            "official": True,
            "company": company,
            "stock_code": str(entry.get("stock_code", "")).strip(),
            "market": market,
        })
    return items


def get_corp_master(body: dict[str, Any]) -> list[dict[str, str]]:
    key = dart_key(body)
    cache_key = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
    if cache_key in CORP_CACHE:
        return CORP_CACHE[cache_key]
    raw = request_bytes("https://opendart.fss.or.kr/api/corpCode.xml", params={"crtfc_key": key}, timeout=30)
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            xml_data = archive.read(archive.namelist()[0])
        root = ElementTree.fromstring(xml_data)
    except (zipfile.BadZipFile, KeyError, ElementTree.ParseError) as error:
        raise ApiProblem("OpenDART 상장사 목록을 읽지 못했습니다") from error
    companies: list[dict[str, str]] = []
    for item in root.findall("list"):
        name = clean_text(item.findtext("corp_name") or "")
        stock_code = clean_text(item.findtext("stock_code") or "")
        if name and stock_code:
            companies.append({
                "name": name,
                "code": stock_code,
                "corp_code": clean_text(item.findtext("corp_code") or ""),
            })
    companies.sort(key=lambda company: len(company["name"]), reverse=True)
    CORP_CACHE[cache_key] = companies
    return companies


def fetch_dart_scan_cached(
    body: dict[str, Any], start: datetime,
) -> tuple[list[dict[str, Any]], list[dict[str, str]], str, bool]:
    """Reuse one just-finished DART scan while keeping manual scans fresh.

    DART's exact receipt-time pages are the slowest source because every result
    page must be read. A 20-second cache only speeds up an immediate re-scan;
    after that the official source is fetched again.
    """
    identity = "\0".join((
        dart_key(body),
        str(body.get("scanWindow", "close")),
        str(body.get("scanMode", "market")),
        "|".join(search_terms(body)),
        str(bool(body.get("kospiEnabled", True))),
        str(bool(body.get("kosdaqEnabled", True))),
    ))
    cache_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    now = time.time()
    cached_items: list[dict[str, Any]] | None = None
    with DART_SCAN_CACHE_LOCK:
        cached = DART_SCAN_CACHE.get(cache_key, {})
        if now - safe_float(cached.get("fetched_at"), 0) <= 20:
            cached_items = [dict(item) for item in cached.get("items", [])]

    cache_hit = cached_items is not None
    items = cached_items if cache_hit else fetch_dart(body, start)
    if not cache_hit:
        with DART_SCAN_CACHE_LOCK:
            DART_SCAN_CACHE[cache_key] = {
                "items": [dict(item) for item in items],
                "fetched_at": time.time(),
            }

    # A moving 1/3/24-hour window can advance slightly between two button
    # presses, so trim cached rows against the new start before returning them.
    items = [
        item for item in items
        if (
            item.get("published", start) >= start
            if item.get("time_known", True)
            else item.get("published", start).date() >= start.date()
        )
    ]
    corp_master: list[dict[str, str]] = []
    master_error = ""
    try:
        corp_master = get_corp_master(body)
    except ApiProblem as error:
        master_error = str(error)
    return items, corp_master, master_error, cache_hit


def classify_event(text: str) -> str:
    lowered = text.lower()
    compact = re.sub(r"[\W_]+", "", lowered)
    for label, words in EVENT_RULES:
        if any(
            word.lower() in lowered or re.sub(r"[\W_]+", "", word.lower()) in compact
            for word in words
        ):
            return label
    return "기타"


def classify_direction(text: str, event_type: str | None = None) -> dict[str, str]:
    """Judge the event's likely direction, not whether a trade is guaranteed."""
    lowered = text.lower()
    compact = re.sub(r"[\W_]+", "", lowered)

    def matched(words: tuple[str, ...]) -> str:
        return next((
            word for word in words
            if word.lower() in lowered or re.sub(r"[\W_]+", "", word.lower()) in compact
        ), "")

    bad = matched(BAD_NEWS_WORDS)
    good = matched(GOOD_NEWS_WORDS)
    varies = matched(DIFFERENT_BY_STOCK_WORDS)
    if good and bad:
        return {"code": "varies", "emoji": "↕", "label": "수혜·피해 갈림", "reason": f"‘{good}’와 ‘{bad}’ 내용이 함께 있어 회사에 따라 수혜 또는 피해가 생깁니다."}
    if bad:
        return {"code": "bad", "emoji": "▼", "label": "불리할 가능성", "reason": f"뉴스 자체에 ‘{bad}’ 내용이 있어 회사 가치에는 불리한 쪽입니다."}
    if good:
        return {"code": "good", "emoji": "▲", "label": "유리할 가능성", "reason": f"뉴스 자체에 ‘{good}’ 내용이 있어 사업 기회에는 유리한 쪽입니다."}
    if varies:
        return {"code": "varies", "emoji": "↕", "label": "수혜·피해 갈림", "reason": f"{varies} 변화로 수혜를 보는 회사와 피해를 보는 회사가 갈립니다."}

    event_type = event_type or classify_event(text)
    defaults = {
        "증자·감자·CB/BW": ("bad", "▼", "불리할 가능성", "새 주식이나 채무가 늘어 기존 주주에게는 불리할 가능성이 큽니다."),
        "지분·M&A·최대주주": ("varies", "↕", "거래 당사자마다 다름", "인수 대상에는 유리할 수 있지만 인수 회사의 자금 부담은 커질 수 있어 당사자별로 다릅니다."),
        "계약 체결·해지": ("good", "▲", "유리할 가능성", "계약·납품 소식은 매출 기회가 늘어나는 내용이라 뉴스 자체는 유리한 쪽입니다. 규모는 따로 확인해야 합니다."),
        "임상·허가·실패": ("good", "▲", "유리할 가능성", "임상·허가 진행은 사업화 가능성이 앞으로 움직이는 내용이라 뉴스 자체는 유리한 쪽입니다."),
        "소송·제재·조사": ("bad", "▼", "불리할 가능성", "소송·제재·조사는 비용과 사업 차질 위험을 키우므로 뉴스 자체는 불리한 쪽입니다."),
        "국가 협력·공급망": ("good", "▲", "유리할 가능성", "협력·공급망 확대는 연결된 회사의 사업 기회를 넓히는 내용이라 유리한 쪽입니다."),
        "정책·환율·원자재": ("varies", "↕", "수혜·피해 갈림", "정책·환율·원자재 변화는 비용 구조와 수출 비중에 따라 수혜 회사와 피해 회사가 갈립니다."),
        "투자·자금 유입": ("good", "▲", "유리할 가능성", "투자금 유입은 사업 확장에 쓸 자금이 들어오는 내용이라 뉴스 자체는 유리한 쪽입니다."),
        "실적·전망 변화": ("varies", "↕", "숫자 확인 필요", "실적·전망 변화는 증가인지 감소인지 숫자를 확인해야 방향이 갈립니다."),
    }
    if event_type in defaults:
        code, emoji, label, reason = defaults[event_type]
        return {"code": code, "emoji": emoji, "label": label, "reason": reason}
    return {"code": "unknown", "emoji": "?", "label": "내용 확인 필요", "reason": "기사에 사건 내용이나 수치가 거의 없어 유리·불리 방향을 읽지 못했습니다."}


def display_title(title: str, companies: list[dict[str, Any]], emoji: str) -> str:
    """Put the direction icon and not-yet-named related stocks in the headline."""
    names = list(dict.fromkeys(str(company.get("name", "")).strip() for company in companies if company.get("name")))
    compact_title = re.sub(r"\s+", "", title).lower()
    missing = [name for name in names if re.sub(r"\s+", "", name).lower() not in compact_title]
    if not missing:
        return f"{emoji} {title}"
    shown = "·".join(missing[:2])
    if len(missing) > 2:
        shown += f" 외 {len(missing) - 2}"
    return f"{emoji} {shown} | {title}"


def item_time_text(item: dict[str, Any]) -> str:
    if item.get("time_known", True):
        return display_time(item["published"])
    return item["published"].strftime("%m월 %d일 · 시각 없음")


def freshness_score(item: dict[str, Any]) -> int:
    """Score recency without inventing an intraday time for date-only DART data."""
    age = max(0.0, (now_kst() - item["published"]).total_seconds())
    if not item.get("time_known", True):
        days = max(0, (now_kst().date() - item["published"].date()).days)
        return 7 if days == 0 else 4 if days == 1 else 2
    if age <= 30 * 60:
        return 15
    if age <= 60 * 60:
        return 13
    if age <= 3 * 60 * 60:
        return 11
    if age <= 6 * 60 * 60:
        return 8
    if age <= 12 * 60 * 60:
        return 6
    if age <= 24 * 60 * 60:
        return 4
    return 2


def opportunity_band_score(base_score: int, direction_code: str) -> int:
    """Put buy-side opportunities above warnings regardless of event size.

    The app is a discovery tool for early upside candidates, not a general
    market-risk feed.  Direction bands make that product intent explicit while
    the base event score still orders stories inside each band.
    """
    base = max(0, min(100, int(round(base_score))))
    if direction_code == "good":
        # Preserve the event/evidence score so routine positive filings do not
        # jump into the 80s merely because they are positive.  The floor only
        # guarantees that an upside candidate stays above warning-only bands.
        return max(60, base)
    if direction_code == "varies":
        return min(59, 35 + round(base * 0.24))
    if direction_code == "unknown":
        return min(39, 20 + round(base * 0.19))
    # Bad news remains searchable as context, but never outranks an upside
    # candidate.  It is deliberately confined to the bottom information band.
    return min(29, round(base * 0.29))


def priority_score(
    *,
    event_type: str,
    text: str,
    official: bool,
    spread: int,
    companies: list[dict[str, Any]],
    post_signal_move: float,
    timing_ready: bool,
    first_item: dict[str, Any],
    direction: str | None = None,
) -> dict[str, Any]:
    impact = IMPACT_POINTS.get(event_type, IMPACT_POINTS["기타"])
    if event_type != "계약 체결·해지" and any(word.lower() in text.lower() for word in IMPACT_BOOST_WORDS):
        impact = min(40, impact + 4)

    direct_count = sum(company.get("relationType") == "direct" for company in companies)
    industry_count = sum(company.get("relationType") != "direct" for company in companies)
    source_points = 4 + min(8, max(0, spread - 1) * 2)
    evidence = min(
        30,
        (14 if official else 0)
        + source_points
        + (4 if direct_count else 2 if companies else 0)
        + (4 if spread >= 3 else 0),
    )
    breadth = min(
        15,
        (3 if companies else 0)
        + min(8, max(0, len(companies) - 1))
        + (4 if industry_count >= 2 else 2 if industry_count else 0),
    )
    freshness = freshness_score(first_item)
    base_score = min(100, impact + evidence + breadth + freshness)
    direction_code = direction or classify_direction(text, event_type)["code"]
    score = opportunity_band_score(base_score, direction_code)
    direction_note = {
        "good": "호재 우선 점수",
        "varies": "수혜·피해가 갈리는 소식",
        "unknown": "방향 확인 전 소식",
        "bad": "악재는 정보용으로 아래 배치",
    }.get(direction_code, "방향 확인 전 소식")
    if not timing_ready:
        note = f"{direction_note} · 주가 반응은 점수와 별도 · 첫 소식 전 분봉 시세 없음"
    else:
        note = f"{direction_note} · 주가 반응은 점수와 별도 · 첫 소식 후 {post_signal_move:+.1f}%"
    return {
        "score": score,
        "breakdown": {
            "impact": impact,
            "evidence": evidence,
            "breadth": breadth,
            "freshness": freshness,
            "base": base_score,
            "direction": direction_code,
        },
        "note": note,
    }


def title_tokens(title: str) -> set[str]:
    value = re.sub(r"\[[^]]+]|\([^)]*(?:종합|속보|상보)[^)]*\)", " ", title.lower())
    tokens = re.findall(r"[가-힣a-z0-9]{2,}", value)
    stop = {"관련", "대한", "위해", "통해", "발표", "공개", "종합", "속보", "상보", "단독"}
    return {token for token in tokens if token not in stop}


def topic_stock_fields(stock: tuple[Any, ...]) -> tuple[str, str, str, str, str, int]:
    """Normalize the curated topic catalog and keep old four-field rows valid."""
    name = str(stock[0])
    code = str(stock[1])
    market = str(stock[2])
    if len(stock) >= 6:
        return name, code, market, str(stock[3]), str(stock[4]), int(stock[5])
    reason = str(stock[3]) if len(stock) >= 4 else "실제 사업 연결"
    return name, code, market, "핵심 사업", reason, 1


def infer_companies(text: str, master: list[dict[str, str]]) -> list[dict[str, str]]:
    compact = re.sub(r"\s+", "", text).lower()
    found: list[dict[str, str]] = []
    seen: set[str] = set()
    for name, (code, market, aliases) in KNOWN_COMPANIES.items():
        if any(re.sub(r"\s+", "", alias).lower() in compact for alias in aliases):
            found.append({
                "name": name, "code": code, "market": market,
                "relationType": "direct", "relationLabel": "직접 언급",
                "reason": "기사·공시에 회사명이 직접 적혀 있음",
            })
            seen.add(code)
    for group in INDUSTRY_TOPICS:
        for stock in group["stocks"]:
            name, code, market, _role, _reason, _tier = topic_stock_fields(stock)
            compact_name = re.sub(r"\s+", "", name).lower()
            if code in seen or len(compact_name) < 3 or compact_name not in compact:
                continue
            found.append({
                "name": name, "code": code, "market": market,
                "relationType": "direct", "relationLabel": "직접 언급",
                "reason": "기사·공시에 회사명이 직접 적혀 있음",
            })
            seen.add(code)
    for company in master:
        name = company["name"]
        code = company["code"]
        if code in seen or len(name) < 3:
            continue
        if re.sub(r"\s+", "", name).lower() in compact:
            found.append({
                "name": name, "code": code, "market": "",
                "relationType": "direct", "relationLabel": "직접 언급",
                "reason": "기사·공시에 회사명이 직접 적혀 있음",
            })
            seen.add(code)
        if len(found) >= 6:
            break
    return found


def infer_industry_companies(text: str) -> list[dict[str, str]]:
    lowered = re.sub(r"\s+", " ", text).lower()
    found: dict[str, dict[str, str]] = {}
    for group in INDUSTRY_TOPICS:
        if not any(keyword.lower() in lowered for keyword in group["keywords"]):
            continue
        for stock in group["stocks"]:
            name, code, market, role, reason, tier = topic_stock_fields(stock)
            candidate = found.get(code)
            topic = str(group["topic"])
            if candidate:
                topics = list(dict.fromkeys((candidate.get("topic", "") + "·" + topic).strip("·").split("·")))
                candidate["topic"] = "·".join(topics)
                candidate["tier"] = str(min(int(candidate.get("tier", "2")), tier))
                continue
            found[code] = {
                "name": name,
                "code": code,
                "market": market,
                "relationType": "industry",
                "relationLabel": role,
                "role": role,
                "tier": str(tier),
                "topic": topic,
                "reason": f"{topic} 연결 · {reason}",
            }
    return list(found.values())[:30]


def companies_for_topics(topics: list[str]) -> list[dict[str, str]]:
    """Return only verified catalog stocks for topic names selected by AI."""
    requested = set(topics)
    found: dict[str, dict[str, str]] = {}
    for group in INDUSTRY_TOPICS:
        topic = str(group["topic"])
        if topic not in requested:
            continue
        for stock in group["stocks"]:
            name, code, market, role, reason, tier = topic_stock_fields(stock)
            if code in found:
                continue
            found[code] = {
                "name": name,
                "code": code,
                "market": market,
                "relationType": "ai",
                "relationLabel": role,
                "role": role,
                "tier": str(tier),
                "topic": topic,
                "reason": f"AI가 ‘{topic}’으로 분류 · 검증된 종목표에서 {reason}",
            }
    return list(found.values())[:30]


def visible_cluster_companies(cluster: dict[str, Any], body: dict[str, Any]) -> list[dict[str, Any]]:
    """Apply the user's relation scope without using price movement as a filter."""
    scope = str(body.get("relatedScope", "broad"))
    limit = max(1, min(int(safe_float(body.get("maxRelatedStocks"), 30)), 30))
    direct = [company for company in cluster.get("companies", []) if company.get("relationType") == "direct"]
    linked = [company for company in cluster.get("companies", []) if company.get("relationType") != "direct"]
    if scope == "direct":
        selected = direct
    elif scope == "core":
        selected = direct + [company for company in linked if int(company.get("tier", 1)) <= 1]
    else:
        selected = direct + [company for company in linked if int(company.get("tier", 2)) <= 2]
    deduped: dict[str, dict[str, Any]] = {}
    for company in selected:
        code = str(company.get("code", ""))
        if code and code not in deduped:
            deduped[code] = company
    return list(deduped.values())[:limit]


def cluster_items(items: list[dict[str, Any]], master: list[dict[str, str]]) -> list[dict[str, Any]]:
    clusters: list[dict[str, Any]] = []
    ordered = sorted(items, key=lambda item: item["published"])
    for item in ordered:
        text = f"{item['title']} {item.get('summary', '')}"
        inference_text = text
        if item.get("company"):
            # Prevent names embedded in the filing company from becoming false
            # related stocks (for example 현대차 inside 현대차증권).
            inference_text = inference_text.replace(str(item["company"]), " ")
        directly_named = infer_companies(inference_text, master)
        industry_linked = infer_industry_companies(inference_text)
        inferred = directly_named + industry_linked
        if item.get("company") and item.get("stock_code"):
            inferred.insert(0, {
                "name": item["company"], "code": item["stock_code"], "market": item.get("market", ""),
                "relationType": "direct", "relationLabel": "직접 언급",
                "reason": "이 회사가 직접 제출한 공식 공시",
            })
        # Direct mentions take priority over an industry-only link for the same stock.
        deduped: dict[str, dict[str, str]] = {}
        for company in inferred:
            code = company.get("code", "")
            if code and (code not in deduped or company.get("relationType") == "direct"):
                deduped[code] = company
        companies = list(deduped.values())
        tokens = title_tokens(item["title"])
        item_event_type = classify_event(text)
        target = None
        for cluster in clusters:
            direct_codes = {
                company["code"] for company in companies
                if company.get("relationType") == "direct"
            }
            cluster_direct_codes = {
                company["code"] for company in cluster["companies"]
                if company.get("relationType") == "direct"
            }
            shared_direct_company = bool(direct_codes & cluster_direct_codes)
            # Generic DART titles such as "채무증권 발행결정" are nearly
            # identical across issuers. They are separate events unless the
            # filing company itself is the same; title overlap alone must not
            # mix one company's direction and timing into another company's card.
            different_dart_companies = (
                item.get("source") == "OpenDART"
                and any(entry.get("source") == "OpenDART" for entry in cluster["items"])
                and bool(direct_codes)
                and bool(cluster_direct_codes)
                and not shared_direct_company
            )
            union = tokens | cluster["tokens"]
            overlap = len(tokens & cluster["tokens"]) / len(union) if union else 0
            latest_cluster_item = max(cluster["items"], key=lambda entry: entry["published"])
            both_times_known = bool(item.get("time_known", True) and latest_cluster_item.get("time_known", True))
            if both_times_known:
                close_in_time = abs((item["published"] - latest_cluster_item["published"]).total_seconds()) <= 3 * 60 * 60
            else:
                close_in_time = item["published"].date() == latest_cluster_item["published"].date()
            same_dart_report_series = False
            if shared_direct_company and item.get("source") == "OpenDART" and latest_cluster_item.get("source") == "OpenDART":
                normalize_report = lambda value: re.sub(
                    r"[\W_]+", "", re.sub(r"\[[^\]]+\]|주요사항보고서|^[^·]+·", "", str(value))
                ).lower()
                same_dart_report_series = (
                    normalize_report(item.get("title", "")) == normalize_report(latest_cluster_item.get("title", ""))
                    and abs((item["published"] - latest_cluster_item["published"]).days) <= 60
                )
            same_typed_company_event = (
                shared_direct_company
                and item_event_type != "기타"
                and item_event_type in cluster["event_types"]
                and close_in_time
            )
            if not different_dart_companies and (
                overlap >= 0.68
                or (shared_direct_company and overlap >= 0.38)
                or same_typed_company_event
                or same_dart_report_series
            ):
                target = cluster
                break
        if target is None:
            clusters.append({
                "items": [item],
                "tokens": set(tokens),
                "companies": companies,
                "event_types": {item_event_type},
            })
        else:
            target["items"].append(item)
            target["tokens"].update(tokens)
            target["event_types"].add(item_event_type)
            existing = {company["code"]: index for index, company in enumerate(target["companies"])}
            for company in companies:
                code = company["code"]
                if code not in existing:
                    target["companies"].append(company)
                elif company.get("relationType") == "direct" and target["companies"][existing[code]].get("relationType") != "direct":
                    target["companies"][existing[code]] = company
    return clusters


def expand_clusters_with_openai(clusters: list[dict[str, Any]], body: dict[str, Any]) -> int:
    """Classify every event in one request, then map only to curated stocks."""
    key = str(body.get("aiKey", "")).strip()
    if not key or str(body.get("aiService", "openai")) != "openai" or not clusters:
        return 0
    topic_names = [str(group["topic"]) for group in INDUSTRY_TOPICS]
    batch = []
    for index, cluster in enumerate(clusters[:30]):
        entries = sorted(cluster.get("items", []), key=lambda item: item["published"])
        batch.append({
            "event": index,
            "title": clean_text(entries[-1].get("title", ""))[:300] if entries else "",
            "summary": clean_text(entries[-1].get("summary", ""))[:500] if entries else "",
        })
    schema = {
        "type": "object",
        "properties": {
            "matches": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "event": {"type": "integer"},
                        "topics": {"type": "array", "items": {"type": "string", "enum": topic_names}},
                        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                    },
                    "required": ["event", "topics", "confidence"],
                    "additionalProperties": False,
                },
            },
        },
        "required": ["matches"],
        "additionalProperties": False,
    }
    data = request_json(
        "https://api.openai.com/v1/responses",
        headers={"Authorization": f"Bearer {key}"},
        payload={
            "model": "gpt-5-nano",
            "input": [
                {
                    "role": "system",
                    "content": [{
                        "type": "input_text",
                        "text": (
                            "한국 주식 뉴스의 산업·원재료·장비·공급망 연결을 분류한다. "
                            "제공된 주제명만 고르고, 단순 단어 유사성이 아니라 실제 사업 연결이 있을 때만 선택한다. "
                            "종목명·종목코드는 만들지 않는다. 여러 주제가 실제로 연결되면 모두 고른다."
                        ),
                    }],
                },
                {"role": "user", "content": [{"type": "input_text", "text": json.dumps(batch, ensure_ascii=False)}]},
            ],
            "text": {"format": {"type": "json_schema", "name": "market_topic_matches", "strict": True, "schema": schema}},
            "max_output_tokens": 4000,
        },
        timeout=35,
    )
    chunks: list[str] = []
    for output in data.get("output", []):
        if not isinstance(output, dict):
            continue
        for content in output.get("content", []):
            if isinstance(content, dict) and content.get("type") == "output_text":
                chunks.append(str(content.get("text", "")))
    if not chunks:
        raise ApiProblem("OpenAI가 산업 분류 결과를 돌려주지 않았습니다")
    try:
        parsed = json.loads("".join(chunks))
    except json.JSONDecodeError as error:
        raise ApiProblem("OpenAI 산업 분류 결과를 읽지 못했습니다") from error
    expanded = 0
    for match in parsed.get("matches", []):
        if not isinstance(match, dict) or safe_float(match.get("confidence")) < 0.45:
            continue
        index = int(safe_float(match.get("event"), -1))
        if index < 0 or index >= len(clusters):
            continue
        topics = [topic for topic in match.get("topics", []) if topic in topic_names]
        additions = companies_for_topics(topics)
        existing = {str(company.get("code", "")): position for position, company in enumerate(clusters[index]["companies"])}
        for company in additions:
            code = company["code"]
            if code not in existing:
                clusters[index]["companies"].append(company)
                existing[code] = len(clusters[index]["companies"]) - 1
                expanded += 1
    return expanded


def kis_base(body: dict[str, Any]) -> str:
    return "https://openapivts.koreainvestment.com:29443" if body.get("kisMode") == "paper" else "https://openapi.koreainvestment.com:9443"


def kis_token(body: dict[str, Any]) -> str:
    app_key = str(body.get("kisAppKey", "")).strip()
    secret = str(body.get("kisAppSecret", "")).strip()
    if not app_key or not secret:
        raise ApiProblem("한국투자 App Key와 App Secret을 모두 입력하세요", 400)
    cache_identity = f"{kis_base(body)}\0{app_key}\0{secret}".encode("utf-8")
    cache_key = hashlib.sha256(cache_identity).hexdigest()

    # KIS limits token issuance.  A connection test followed immediately by a
    # scan must reuse the same in-memory token instead of requesting another.
    # The token and credentials are never written to disk.
    with KIS_TOKEN_LOCK:
        now = time.time()
        cached = KIS_TOKEN_CACHE.get(cache_key, {})
        if str(cached.get("token", "")) and safe_float(cached.get("expires_at")) > now + 60:
            return str(cached["token"])

        data = request_json(f"{kis_base(body)}/oauth2/tokenP", payload={
            "grant_type": "client_credentials",
            "appkey": app_key,
            "appsecret": secret,
        })
        token = str(data.get("access_token", ""))
        if not token:
            raise ApiProblem(str(data.get("error_description") or "한국투자 토큰을 발급받지 못했습니다"))
        expires_in = max(60.0, safe_float(data.get("expires_in"), 86400.0))
        KIS_TOKEN_CACHE[cache_key] = {
            "token": token,
            "expires_at": now + max(60.0, expires_in - 300.0),
        }
        return token


def kis_quote(body: dict[str, Any], token: str, stock_code: str) -> dict[str, Any]:
    app_key = str(body.get("kisAppKey", "")).strip()
    secret = str(body.get("kisAppSecret", "")).strip()
    data = request_json(
        f"{kis_base(body)}/uapi/domestic-stock/v1/quotations/inquire-price",
        headers={
            "authorization": f"Bearer {token}",
            "appkey": app_key,
            "appsecret": secret,
            "tr_id": "FHKST01010100",
            "custtype": "P",
        },
        params={"FID_COND_MRKT_DIV_CODE": "J", "FID_INPUT_ISCD": stock_code},
    )
    if str(data.get("rt_cd", "0")) != "0":
        raise ApiProblem(str(data.get("msg1") or "한국투자 현재가 조회 실패"))
    output = data.get("output") or {}
    return {
        "price": safe_float(output.get("stck_prpr")),
        "change": safe_float(output.get("prdy_ctrt")),
        "volume": safe_float(output.get("acml_vol")),
    }


def retryable_kis_error(error: ApiProblem) -> bool:
    message = str(error).lower()
    return error.status >= 500 or any(marker in message for marker in ("egw00201", "초당", "429", "시간 초과", "연결 실패"))


def kis_request_with_retry(body: dict[str, Any], request: Any) -> Any:
    """Retry one temporary KIS failure without ever issuing a new token."""
    try:
        return request()
    except ApiProblem as error:
        if not retryable_kis_error(error):
            raise
        time.sleep(0.65 if body.get("kisMode") == "paper" else 0.25)
        return request()


def kis_quote_cached(body: dict[str, Any], token: str, stock_code: str) -> tuple[dict[str, Any], bool]:
    cache_key = (kis_base(body), stock_code)
    now = time.time()
    with KIS_DATA_CACHE_LOCK:
        cached = KIS_QUOTE_CACHE.get(cache_key, {})
        if now - safe_float(cached.get("fetched_at"), 0) <= 15:
            return dict(cached.get("quote", {})), True
    quote = dict(kis_request_with_retry(body, lambda: kis_quote(body, token, stock_code)))
    quote["quoteAt"] = now_kst().isoformat()
    with KIS_DATA_CACHE_LOCK:
        KIS_QUOTE_CACHE[cache_key] = {"quote": dict(quote), "fetched_at": time.time()}
    return quote, False


def kis_baseline_cached(
    body: dict[str, Any], token: str, stock_code: str, signal_at: datetime,
) -> tuple[dict[str, Any], bool]:
    cache_key = (kis_base(body), stock_code, signal_at.isoformat())
    with KIS_DATA_CACHE_LOCK:
        cached = KIS_BASELINE_CACHE.get(cache_key)
        if cached:
            return dict(cached), True
    baseline = kis_request_with_retry(
        body,
        lambda: kis_signal_baseline(body, token, stock_code, signal_at),
    )
    with KIS_DATA_CACHE_LOCK:
        KIS_BASELINE_CACHE[cache_key] = dict(baseline)
    return baseline, False


def elapsed_korean(start: datetime, end: datetime) -> str:
    seconds = max(0, int((end.astimezone(KST) - start.astimezone(KST)).total_seconds()))
    minutes = seconds // 60
    if minutes < 1:
        return "1분 안 됨"
    days, remaining_minutes = divmod(minutes, 24 * 60)
    hours, mins = divmod(remaining_minutes, 60)
    parts: list[str] = []
    if days:
        parts.append(f"{days}일")
    if hours:
        parts.append(f"{hours}시간")
    if mins and len(parts) < 2:
        parts.append(f"{mins}분")
    return " ".join(parts) or "1분 안 됨"


def previous_market_day(value: datetime) -> datetime:
    candidate = value - timedelta(days=1)
    while candidate.weekday() >= 5:
        candidate -= timedelta(days=1)
    return candidate


def signal_baseline_target(signal_at: datetime) -> tuple[datetime, str]:
    """Return the last regular-session minute that existed before a public signal."""
    signal = signal_at.astimezone(KST)
    minute_of_day = signal.hour * 60 + signal.minute
    if signal.weekday() < 5 and 9 * 60 < minute_of_day < 15 * 60 + 30:
        return signal.replace(second=0, microsecond=0) - timedelta(minutes=1), "첫 소식 직전"
    if signal.weekday() < 5 and minute_of_day >= 15 * 60 + 30:
        return signal.replace(hour=15, minute=30, second=0, microsecond=0), "첫 소식 전 장마감"
    prior = previous_market_day(signal)
    return prior.replace(hour=15, minute=30, second=0, microsecond=0), "첫 소식 전 장마감"


def parse_kis_minute_rows(rows: Any, query_day: datetime) -> list[dict[str, Any]]:
    parsed: list[dict[str, Any]] = []
    if not isinstance(rows, list):
        return parsed
    for row in rows:
        if not isinstance(row, dict):
            continue
        date_text = str(row.get("stck_bsop_date") or query_day.strftime("%Y%m%d"))
        raw_clock = re.sub(r"\D", "", str(row.get("stck_cntg_hour") or ""))
        if not raw_clock:
            continue
        clock_text = raw_clock.zfill(6)[-6:]
        price = safe_float(row.get("stck_prpr"))
        if len(date_text) != 8 or price <= 0:
            continue
        try:
            at = datetime.strptime(date_text + clock_text, "%Y%m%d%H%M%S").replace(tzinfo=KST)
        except ValueError:
            continue
        parsed.append({"at": at, "price": price})
    return parsed


def kis_signal_baseline(
    body: dict[str, Any], token: str, stock_code: str, signal_at: datetime,
) -> dict[str, Any]:
    """Fetch the tradable price immediately before the earliest public signal."""
    app_key = str(body.get("kisAppKey", "")).strip()
    secret = str(body.get("kisAppSecret", "")).strip()
    target, target_label = signal_baseline_target(signal_at)
    query_target = target
    for attempt in range(4):
        data = request_json(
            f"{kis_base(body)}/uapi/domestic-stock/v1/quotations/inquire-time-dailychartprice",
            headers={
                "authorization": f"Bearer {token}",
                "appkey": app_key,
                "appsecret": secret,
                "tr_id": "FHKST03010230",
                "custtype": "P",
            },
            params={
                "FID_COND_MRKT_DIV_CODE": "J",
                "FID_INPUT_ISCD": stock_code,
                "FID_INPUT_HOUR_1": query_target.strftime("%H%M%S"),
                "FID_INPUT_DATE_1": query_target.strftime("%Y%m%d"),
                "FID_PW_DATA_INCU_YN": "Y",
                "FID_FAKE_TICK_INCU_YN": "",
            },
        )
        if str(data.get("rt_cd", "0")) != "0":
            raise ApiProblem(str(data.get("msg1") or "한국투자 분봉 조회 실패"))
        candidates = [
            point for point in parse_kis_minute_rows(data.get("output2"), query_target)
            if point["at"] <= query_target
        ]
        if candidates:
            selected = max(candidates, key=lambda point: point["at"])
            label = target_label if attempt == 0 else "첫 소식 전 마지막 거래"
            return {"price": selected["price"], "at": selected["at"], "label": label}
        prior = previous_market_day(query_target)
        query_target = prior.replace(hour=15, minute=30, second=0, microsecond=0)
    raise ApiProblem("첫 소식 전 분봉 가격을 찾지 못했습니다")


def cluster_priority_key(cluster: dict[str, Any]) -> tuple[int, bool, int]:
    """Return the same price-independent opportunity key used by final cards."""
    entries = sorted(cluster.get("items", []), key=lambda item: item["published"])
    if not entries:
        return (-1, False, 0)
    first = entries[0]
    first_known = next((item for item in entries if item.get("time_known", True)), first)
    event_text = " ".join(f"{item['title']} {item.get('summary', '')}" for item in entries)
    event_type = classify_event(event_text)
    official = any(item.get("official") for item in entries)
    spread = len({item["source"] for item in entries if item.get("source")})
    priority = priority_score(
        event_type=event_type,
        text=event_text,
        official=official,
        spread=spread,
        companies=cluster.get("companies", []),
        post_signal_move=0,
        timing_ready=False,
        first_item=first_known,
    )
    return (priority["score"], official, spread)


def quote_target_clusters(clusters: list[dict[str, Any]], body: dict[str, Any]) -> list[dict[str, Any]]:
    """Choose up to the user limit for each visible direction."""
    event_limit = max(1, min(int(safe_float(body.get("maxEvents"), 30)), 30))
    selected: list[dict[str, Any]] = []
    direction_counts = {"good": 0, "bad": 0, "varies": 0}
    seen_codes = {"good": set(), "bad": set(), "varies": set()}
    for cluster in sorted(clusters, key=cluster_priority_key, reverse=True):
        entries = cluster.get("items", [])
        if not entries:
            continue
        companies = visible_cluster_companies(cluster, body)
        event_text = " ".join(f"{item['title']} {item.get('summary', '')}" for item in entries)
        official = any(item.get("official") for item in entries)
        event_type = classify_event(event_text)
        direction = classify_direction(event_text, event_type)["code"]
        if direction not in direction_counts or direction_counts[direction] >= event_limit:
            continue
        if event_type == "기타" and not companies and not official:
            continue
        markets = {str(company.get("market")) for company in companies if company.get("market")} or {"kospi"}
        market_enabled = (
            ("kospi" in markets and body.get("kospiEnabled", True))
            or ("kosdaq" in markets and body.get("kosdaqEnabled", True))
        )
        if not market_enabled:
            continue
        direct_codes = {
            str(company.get("code")) for company in companies
            if company.get("code") and company.get("relationType") == "direct"
        }
        if body.get("onePerCompany", True) and direct_codes & seen_codes[direction]:
            continue
        selected.append(cluster)
        seen_codes[direction].update(direct_codes)
        direction_counts[direction] += 1
        if all(count >= event_limit for count in direction_counts.values()):
            break
    return selected


def build_events(
    clusters: list[dict[str, Any]], body: dict[str, Any], scanned_at: datetime | None = None,
) -> tuple[list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    quote_map: dict[str, dict[str, Any]] = {}
    quote_requested: set[str] = set()
    quote_failures: dict[str, str] = {}
    baseline_cache: dict[tuple[str, str], dict[str, Any] | None] = {}
    baseline_targets: set[tuple[int, str]] = set()
    kis_access_token = ""
    kis_connection_error = ""
    scanned_at = (scanned_at or now_kst()).astimezone(KST)

    kis_ready = bool(str(body.get("kisAppKey", "")).strip() and str(body.get("kisAppSecret", "")).strip())
    if kis_ready:
        try:
            kis_access_token = kis_token(body)
            candidate_codes: list[str] = []
            ranked_clusters = quote_target_clusters(clusters, body)
            for cluster in ranked_clusters:
                available = [company for company in visible_cluster_companies(cluster, body) if company.get("code")]
                direct = [company for company in available if company.get("relationType") == "direct"]
                linked = [company for company in available if company.get("relationType") != "direct"]
                # Directly named stocks come first, but every related stock
                # shown on the card receives the same first-signal comparison.
                for company in direct + linked:
                    code = str(company.get("code", ""))
                    if not code:
                        continue
                    baseline_targets.add((id(cluster), code))
                    if code and code not in candidate_codes:
                        candidate_codes.append(code)

            def load_quote(code: str) -> tuple[str, dict[str, Any] | None, str]:
                try:
                    quote, cached = kis_quote_cached(body, kis_access_token, code)
                    if not cached:
                        time.sleep(0.52 if body.get("kisMode") == "paper" else 0.12)
                    return code, quote, ""
                except ApiProblem as error:
                    return code, None, str(error)

            # The production KIS REST limit can handle a small amount of
            # concurrency. Paper trading is intentionally kept serial because
            # its allowance is lower.
            quote_workers = 1 if body.get("kisMode") == "paper" else min(3, len(candidate_codes) or 1)
            with ThreadPoolExecutor(max_workers=quote_workers, thread_name_prefix="kis-quotes") as executor:
                for code, quote, error_message in executor.map(load_quote, candidate_codes):
                    quote_requested.add(code)
                    if quote:
                        quote_map[code] = quote
                    else:
                        quote_failures[code] = error_message

            baseline_jobs: list[tuple[tuple[str, str], str, datetime]] = []
            scheduled_baselines: set[tuple[str, str]] = set()
            for cluster in ranked_clusters:
                entries = sorted(cluster.get("items", []), key=lambda item: item["published"])
                if not entries:
                    continue
                first = entries[0]
                first_known = next((item for item in entries if item.get("time_known", True)), first)
                if not first_known.get("time_known", True):
                    continue
                for company in visible_cluster_companies(cluster, body):
                    code = str(company.get("code", ""))
                    if not code or code not in quote_map or (id(cluster), code) not in baseline_targets:
                        continue
                    baseline_key = (code, first_known["published"].isoformat())
                    if baseline_key in scheduled_baselines:
                        continue
                    scheduled_baselines.add(baseline_key)
                    baseline_jobs.append((baseline_key, code, first_known["published"]))

            def load_baseline(
                job: tuple[tuple[str, str], str, datetime],
            ) -> tuple[tuple[str, str], dict[str, Any] | None, str]:
                baseline_key, code, signal_at = job
                try:
                    baseline, cached = kis_baseline_cached(body, kis_access_token, code, signal_at)
                    if not cached:
                        time.sleep(0.52 if body.get("kisMode") == "paper" else 0.12)
                    return baseline_key, baseline, ""
                except ApiProblem as error:
                    return baseline_key, None, str(error)

            baseline_workers = 1 if body.get("kisMode") == "paper" else min(3, len(baseline_jobs) or 1)
            with ThreadPoolExecutor(max_workers=baseline_workers, thread_name_prefix="kis-baselines") as executor:
                for baseline_key, baseline, error_message in executor.map(load_baseline, baseline_jobs):
                    baseline_cache[baseline_key] = baseline
        except ApiProblem as error:
            kis_connection_error = str(error)
            warnings.append(f"한국투자 시세 연결 실패: {error}")

    events: list[dict[str, Any]] = []
    move_threshold = safe_float(body.get("moveThreshold"), 5.0)
    for index, cluster in enumerate(clusters):
        entries = sorted(cluster["items"], key=lambda item: item["published"])
        first = entries[0]
        latest = entries[-1]
        first_known = next((item for item in entries if item.get("time_known", True)), first)
        signal_at = first_known["published"].astimezone(KST)
        signal_time_known = bool(first_known.get("time_known", True))
        signal_elapsed = elapsed_korean(signal_at, scanned_at) if signal_time_known else "지난 시간 확인 못함"
        if first_known.get("source") == "OpenDART":
            first_signal_label = "공시"
        elif first_known.get("official"):
            first_signal_label = "공식 발표"
        else:
            first_signal_label = "첫 기사"
        event_text = " ".join(f"{item['title']} {item.get('summary', '')}" for item in entries)
        event_type = classify_event(event_text)
        direction = classify_direction(event_text, event_type)
        domains = {item["source"] for item in entries if item.get("source")}
        official = any(item.get("official") for item in entries)
        companies: list[dict[str, Any]] = []
        quote_ready = False
        timing_ready = False
        selected_companies = visible_cluster_companies(cluster, body)
        for company in selected_companies:
            code = str(company.get("code", ""))
            quote = quote_map.get(code, {})
            company_quote_ready = code in quote_map and safe_float(quote.get("price")) > 0
            if company_quote_ready:
                quote_status = "connected"
            elif not kis_ready:
                quote_status = "not-configured"
            elif kis_connection_error:
                quote_status = "connection-error"
            elif code in quote_failures or code in quote_requested:
                quote_status = "failed"
            else:
                quote_status = "not-requested"
            quote_ready = quote_ready or company_quote_ready
            baseline: dict[str, Any] | None = None
            post_signal_move = 0.0
            company_timing_ready = False
            if (
                company_quote_ready
                and first_known.get("time_known", True)
                and kis_access_token
                and (id(cluster), code) in baseline_targets
            ):
                baseline_key = (code, first_known["published"].isoformat())
                if baseline_key not in baseline_cache:
                    try:
                        baseline_cache[baseline_key], cached = kis_baseline_cached(
                            body, kis_access_token, code, first_known["published"],
                        )
                        if not cached:
                            time.sleep(0.52 if body.get("kisMode") == "paper" else 0.12)
                    except ApiProblem:
                        baseline_cache[baseline_key] = None
                baseline = baseline_cache.get(baseline_key)
                baseline_price = safe_float(baseline.get("price")) if baseline else 0.0
                scan_price = safe_float(quote.get("price"))
                if baseline_price > 0 and scan_price > 0:
                    post_signal_move = (scan_price / baseline_price - 1) * 100
                    company_timing_ready = True
                    timing_ready = True
            relation_type = company.get("relationType", "direct")
            if relation_type == "direct":
                impact_label = "직접 언급"
            else:
                impact_label = str(company.get("role") or company.get("relationLabel") or "사업 연결")
            companies.append({
                **company,
                "price": safe_float(quote.get("price")),
                "quoteAt": str(quote.get("quoteAt", "")),
                "quoteReady": company_quote_ready,
                "quoteStatus": quote_status,
                "quoteMessage": quote_failures.get(code, "") if quote_status == "failed" else kis_connection_error if quote_status == "connection-error" else "",
                "timingReady": company_timing_ready,
                "postSignalMove": round(post_signal_move, 2),
                "baselinePrice": safe_float(baseline.get("price")) if baseline else 0.0,
                "baselineAt": baseline.get("at").isoformat() if baseline and baseline.get("at") else "",
                "baselineLabel": str(baseline.get("label", "")) if baseline else "",
                "impactLabel": impact_label,
            })
        timed_companies = [company for company in companies if company.get("timingReady")]
        direct_timed_companies = [
            company for company in timed_companies if company.get("relationType") == "direct"
        ]
        timing_pool = direct_timed_companies or timed_companies
        timing_anchor = max(
            timing_pool,
            key=lambda company: abs(safe_float(company.get("postSignalMove"))),
        ) if timing_pool else None
        anchor_post_signal_move = safe_float(timing_anchor.get("postSignalMove")) if timing_anchor else 0.0
        comparison_at = parse_iso_date(str(timing_anchor.get("quoteAt"))) if timing_anchor and timing_anchor.get("quoteAt") else scanned_at
        signal_elapsed = elapsed_korean(signal_at, comparison_at) if signal_time_known else "지난 시간 확인 못함"
        timing_stock = str(timing_anchor.get("name", "")) if timing_anchor else ""
        kind = "reacted" if timing_ready and abs(anchor_post_signal_move) >= move_threshold else "lead"
        market = next((company.get("market") for company in companies if company.get("market")), "kospi")
        markets = list(dict.fromkeys(str(company.get("market")) for company in companies if company.get("market"))) or [market]
        if event_type == "기타" and not companies and not official:
            continue
        source_list = [{
            "name": item["source"],
            "url": item["link"],
            "time": item_time_text(item),
            "official": bool(item.get("official")),
        } for item in entries[:8]]
        timing_moves = sorted(safe_float(company.get("postSignalMove")) for company in timing_pool)
        if not timing_moves:
            post_signal_text = "확인 불가"
        elif abs(timing_moves[-1] - timing_moves[0]) < 0.05:
            post_signal_text = f"{timing_moves[0]:+.1f}%"
        else:
            post_signal_text = f"{timing_moves[0]:+.1f}~{timing_moves[-1]:+.1f}%"
        if timing_ready:
            baseline_label = str(timing_anchor.get("baselineLabel") or "첫 소식 직전")
            baseline_short = "장마감가" if "장마감" in baseline_label else "직전가"
            move_text = f"{timing_stock} · {baseline_short} 대비 {post_signal_text} · {signal_elapsed} 뒤"
        elif quote_ready and not first_known.get("time_known", True):
            move_text = "현재가는 연결됨 · 공개시각 확인 필요"
        elif quote_ready:
            move_text = "현재가는 연결됨 · 기준 분봉 없음"
        elif kis_ready:
            move_text = "표시 종목 시세 조회 안 됨"
        else:
            move_text = "한투 API 미입력"
        if signal_time_known and timing_ready:
            baseline_price = safe_float(timing_anchor.get("baselinePrice"))
            scan_price = safe_float(timing_anchor.get("price"))
            timing_summary = (
                f"{first_signal_label} {display_time(signal_at)} → 검색 {display_time(comparison_at)}"
                f" · {signal_elapsed} 뒤 · {timing_stock} {baseline_short} "
                f"{baseline_price:,.0f}→{scan_price:,.0f}원 ({post_signal_text})"
            )
        elif signal_time_known:
            timing_summary = (
                f"{first_signal_label} {display_time(signal_at)} → 내 검색 {display_time(scanned_at)}"
                f" · {signal_elapsed} · 가격 비교 못함"
            )
        else:
            timing_summary = "공시 시각 없음 · 가격 비교 생략"
        first_news = next((item for item in entries if item.get("source") != "OpenDART" and not item.get("official")), None)
        first_official = next((item for item in entries if item.get("source") == "OpenDART" or item.get("official")), None)
        timeline: list[dict[str, Any]] = []
        seen_timeline_links: set[str] = set()
        official_label = "공시 접수" if first_official and first_official.get("source") == "OpenDART" else "공식 발표"
        for item, label, kind_name in (
            (first_news, "첫 기사", "news"),
            (first_official, official_label, "official"),
        ):
            if not item:
                continue
            item_link = str(item.get("link", ""))
            if item_link and item_link in seen_timeline_links:
                continue
            if item_link:
                seen_timeline_links.add(item_link)
            time_known = bool(item.get("time_known", True))
            source_name = str(item.get("source", "")).strip()
            timeline.append({
                "label": label if time_known else f"{label}일",
                "value": f"{item_time_text(item)}{f' · {source_name}' if source_name else ''}",
                "at": item["published"].isoformat() if time_known else "",
                "kind": kind_name if time_known else "unknown-time",
                "exactTime": time_known,
            })
        if not timeline:
            timeline.append({
                "label": "최초 공개",
                "value": item_time_text(first_known),
                "at": first_known["published"].isoformat() if first_known.get("time_known", True) else "",
                "kind": "official" if first_known.get("official") else "news",
                "exactTime": bool(first_known.get("time_known", True)),
            })
        timeline.sort(key=lambda step: (not bool(step.get("at")), str(step.get("at", ""))))
        event_key_seed = f"{first_known.get('link', '')}|{first_known.get('title', '')}"
        event_key = hashlib.sha1(event_key_seed.encode("utf-8")).hexdigest()[:20]
        priority = priority_score(
            event_type=event_type,
            text=event_text,
            official=official,
            spread=len(domains),
            companies=cluster["companies"],
            post_signal_move=anchor_post_signal_move,
            timing_ready=timing_ready,
            first_item=first_known,
            direction=direction["code"],
        )
        if timing_stock:
            direction_note = {
                "good": "호재 우선 점수",
                "varies": "수혜·피해가 갈리는 소식",
                "unknown": "방향 확인 전 소식",
                "bad": "악재는 정보용으로 아래 배치",
            }.get(direction["code"], "방향 확인 전 소식")
            priority["note"] = (
                f"{direction_note} · 주가 반응은 점수와 별도 · "
                f"첫 소식부터 검색까지 {signal_elapsed} · {timing_stock} {post_signal_text}"
            )
        headline = display_title(latest["title"], companies, direction["emoji"])
        events.append({
            "id": f"live-{index}",
            "eventKey": event_key,
            "kind": kind,
            "market": market,
            "markets": markets,
            "move": round(abs(anchor_post_signal_move), 2),
            "postSignalMove": round(anchor_post_signal_move, 2),
            "timingStock": timing_stock,
            "volume": 0,
            "spread": len(domains),
            "official": official,
            "quoteReady": quote_ready,
            "timingReady": timing_ready,
            "score": priority["score"],
            "scoreBreakdown": priority["breakdown"],
            "scoreNote": priority["note"],
            "direction": direction["code"],
            "directionEmoji": direction["emoji"],
            "directionLabel": direction["label"],
            "directionReason": direction["reason"],
            "title": latest["title"],
            "displayTitle": headline,
            "relatedStocks": [company["name"] for company in companies],
            "summary": latest.get("summary") or "원문에서 구체적인 숫자와 조건을 확인하세요.",
            "eventType": event_type,
            "published": item_time_text(first_known),
            "signalAt": signal_at.isoformat() if signal_time_known else "",
            "signalLabel": first_signal_label,
            "scannedAtIso": scanned_at.isoformat(),
            "comparisonAt": comparison_at.isoformat(),
            "elapsedText": signal_elapsed,
            "postSignalText": post_signal_text,
            "moveText": move_text,
            "timingSummary": timing_summary,
            "compact": f"관련 종목 {len(companies)}개 · {move_text}",
            "link": first_known["link"],
            "companies": companies,
            "sources": source_list,
            "timeline": timeline,
        })
    events.sort(key=lambda event: (event["score"], event["official"], event["spread"]), reverse=True)
    return events, warnings


def test_source(body: dict[str, Any]) -> dict[str, Any]:
    source = body.get("source")
    if source == "naver":
        items = fetch_naver(body, "코스피", 1)
        return {"message": f"NAVER 뉴스 연결 성공 · 시험 결과 {len(items)}건"}
    if source == "dart":
        items = fetch_dart(body, now_kst() - timedelta(days=1))
        return {"message": f"OpenDART 연결 성공 · 최근 공시 {len(items)}건 확인"}
    if source == "kis":
        token = kis_token(body)
        quote = kis_quote(body, token, "005930")
        try:
            baseline = kis_signal_baseline(body, token, "005930", now_kst())
        except ApiProblem as error:
            raise ApiProblem(f"현재가는 연결됐지만 첫 소식 전 분봉 조회 실패: {error}") from error
        return {
            "message": (
                f"한국투자 연결 성공 · 현재가 {quote['price']:,.0f}원 · "
                f"분봉 기준가 {baseline['price']:,.0f}원 확인"
            )
        }
    if source == "finnhub":
        key = str(body.get("globalKey", "")).strip()
        if not key:
            raise ApiProblem("Finnhub API Key를 입력하세요", 400)
        items = fetch_global_news(body, now_kst() - timedelta(hours=24))
        return {"message": f"Finnhub 연결 성공 · 한국 시장 관련 외신 {len(items)}건"}
    if source == "newsapi":
        key = str(body.get("globalKey", "")).strip()
        if not key:
            raise ApiProblem("NewsAPI API Key를 입력하세요", 400)
        data = request_json("https://newsapi.org/v2/everything", params={"q": "Korea stocks", "language": "en", "pageSize": 1, "apiKey": key})
        return {"message": f"NewsAPI 연결 성공 · 검색 가능 {data.get('totalResults', 0)}건"}
    if source == "gnews":
        key = str(body.get("globalKey", "")).strip()
        if not key:
            raise ApiProblem("GNews API Key를 입력하세요", 400)
        data = request_json("https://gnews.io/api/v4/search", params={"q": "Korea stocks", "lang": "en", "max": 1, "apikey": key})
        return {"message": f"GNews 연결 성공 · 시험 결과 {len(data.get('articles', []))}건"}
    if source == "openai":
        key = str(body.get("aiKey", "")).strip()
        if not key:
            raise ApiProblem("OpenAI API Key를 입력하세요", 400)
        data = request_json("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"})
        return {"message": f"OpenAI 연결 성공 · 사용 가능 모델 {len(data.get('data', []))}개"}
    raise ApiProblem("이 시험판에서 아직 연결하지 않은 서비스입니다", 400)


def run_scan(body: dict[str, Any]) -> dict[str, Any]:
    run_started = time.perf_counter()
    scanned_at = now_kst()
    keyword_mode = str(body.get("scanMode", "market")) == "keyword"
    terms = search_terms(body)
    if keyword_mode and not terms:
        raise ApiProblem("검색어를 입력하세요", 400)
    if keyword_mode and not body.get("searchDart", True) and not body.get("searchNaver", True):
        raise ApiProblem("네이버 뉴스 또는 OpenDART 공시를 하나 이상 선택하세요", 400)
    if not body.get("kospiEnabled", True) and not body.get("kosdaqEnabled", True):
        raise ApiProblem("KOSPI 또는 KOSDAQ을 하나 이상 선택하세요", 400)
    start = scan_start(str(body.get("scanWindow", "close")))
    raw: list[dict[str, Any]] = []
    statuses: list[str] = []
    errors: list[str] = []
    master: list[dict[str, str]] = []
    service_health: list[dict[str, str]] = []

    collection_started = time.perf_counter()
    jobs: list[tuple[str, Any]] = []
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="market-sources") as executor:
        dart_enabled = not keyword_mode or body.get("searchDart", True)
        naver_enabled = not keyword_mode or body.get("searchNaver", True)
        if dart_enabled and str(body.get("dartKey", "")).strip():
            jobs.append(("dart", executor.submit(fetch_dart_scan_cached, body, start)))
        elif dart_enabled:
            service_health.append({"name": "공시", "state": "off", "detail": "키 없음"})
        if naver_enabled and str(body.get("naverId", "")).strip() and str(body.get("naverSecret", "")).strip():
            jobs.append(("naver", executor.submit(fetch_naver_scan, body, start)))
        elif naver_enabled:
            service_health.append({"name": "뉴스", "state": "off", "detail": "키 없음"})
        if not keyword_mode and str(body.get("globalKey", "")).strip():
            jobs.append(("global", executor.submit(fetch_global_news, body, start)))

        for source, future in jobs:
            try:
                result = future.result()
                if source == "dart":
                    dart_items, master, master_error, dart_cached = result
                    raw.extend(dart_items)
                    cache_note = " · 바로 전 검색 재사용" if dart_cached else ""
                    statuses.append(f"OpenDART {len(dart_items)}건{cache_note}")
                    state = "warn" if master_error else "ok"
                    service_health.append({"name": "공시", "state": state, "detail": f"{len(dart_items)}건"})
                    if master_error:
                        errors.append(f"상장사 목록: {master_error}")
                elif source == "naver":
                    naver_items, naver_errors, cached_queries = result
                    raw.extend(naver_items)
                    cache_note = f" · 재검색 {cached_queries}개 재사용" if cached_queries else ""
                    statuses.append(f"NAVER 뉴스 {len(naver_items)}건{cache_note}")
                    service_health.append({
                        "name": "뉴스",
                        "state": "warn" if naver_errors else "ok",
                        "detail": f"{len(naver_items)}건",
                    })
                    if naver_errors:
                        errors.append(f"NAVER 뉴스 일부 검색 실패({len(naver_errors)}개): {naver_errors[0]}")
                else:
                    global_items = result
                    raw.extend(global_items)
                    service_names = {"finnhub": "Finnhub 외신", "newsapi": "NewsAPI 외신", "gnews": "GNews 외신"}
                    service_name = service_names.get(str(body.get("globalService")), "해외 뉴스")
                    statuses.append(f"{service_name} {len(global_items)}건")
                    service_health.append({"name": "외신", "state": "ok", "detail": f"{len(global_items)}건"})
            except ApiProblem as error:
                label = {"dart": "OpenDART", "naver": "NAVER 뉴스", "global": "해외 뉴스"}[source]
                errors.append(f"{label}: {error}")
                health_name = {"dart": "공시", "naver": "뉴스", "global": "외신"}[source]
                service_health.append({"name": health_name, "state": "error", "detail": "연결 실패"})
    collection_seconds = time.perf_counter() - collection_started

    if not raw:
        if not errors:
            any_key = any(str(body.get(name, "")).strip() for name in ("naverId", "dartKey", "globalKey"))
            if any_key:
                raise ApiProblem("선택한 시간 안에 조건에 맞는 뉴스·공시가 없습니다. 최근 24시간으로 다시 검색해보세요", 404)
            raise ApiProblem("먼저 설정에서 NAVER 뉴스, OpenDART 또는 해외 뉴스 API 키를 입력하세요", 400)
        raise ApiProblem(" · ".join(errors), 502)

    analysis_started = time.perf_counter()
    clusters = cluster_items(raw, master)
    if str(body.get("aiKey", "")).strip():
        try:
            expanded = expand_clusters_with_openai(clusters, body)
            statuses.append(f"AI 산업 연결 {expanded}개 추가 · 스캔당 1회")
        except ApiProblem as error:
            errors.append(f"AI 산업 연결: {error}")
    analysis_seconds = time.perf_counter() - analysis_started
    market_started = time.perf_counter()
    events, quote_warnings = build_events(clusters, body, scanned_at)
    market_seconds = time.perf_counter() - market_started
    errors.extend(quote_warnings)
    maximum = max(1, min(int(safe_float(body.get("maxEvents"), 30)), 30))
    market_events = [
        event for event in events
        if ("kospi" in event.get("markets", [event["market"]]) and body.get("kospiEnabled", True))
        or ("kosdaq" in event.get("markets", [event["market"]]) and body.get("kosdaqEnabled", True))
    ]
    selected: list[dict[str, Any]] = []
    direction_counts = {"good": 0, "bad": 0, "varies": 0}
    seen_codes = {"good": set(), "bad": set(), "varies": set()}
    duplicate_companies = 0
    for event in market_events:
        direction = str(event.get("direction", "unknown"))
        if direction not in direction_counts or direction_counts[direction] >= maximum:
            continue
        codes = {
            company.get("code", "") for company in event.get("companies", [])
            if company.get("code") and company.get("relationType") == "direct"
        }
        if body.get("onePerCompany", True) and codes & seen_codes[direction]:
            duplicate_companies += 1
            continue
        selected.append(event)
        seen_codes[direction].update(codes)
        direction_counts[direction] += 1
        if all(count >= maximum for count in direction_counts.values()):
            break
    for rank, event in enumerate(selected, start=1):
        event["rank"] = rank
    company_statuses = {
        str(company.get("quoteStatus", ""))
        for event in selected for company in event.get("companies", [])
    }
    connected_codes = {
        str(company.get("code", ""))
        for event in selected for company in event.get("companies", [])
        if company.get("quoteStatus") == "connected" and company.get("code")
    }
    kis_configured = bool(str(body.get("kisAppKey", "")).strip() and str(body.get("kisAppSecret", "")).strip())
    if not kis_configured:
        service_health.append({"name": "주가", "state": "off", "detail": "한투 키 없음"})
    elif connected_codes:
        service_health.append({"name": "주가", "state": "ok", "detail": f"{len(connected_codes)}종목"})
    elif "connection-error" in company_statuses:
        service_health.append({"name": "주가", "state": "error", "detail": "한투 연결 실패"})
    else:
        service_health.append({"name": "주가", "state": "warn", "detail": "조회 결과 없음"})
    total_seconds = time.perf_counter() - run_started
    return {
        "live": True,
        "scanMode": "keyword" if keyword_mode else "market",
        "searchKeyword": ", ".join(terms),
        "scannedAt": scanned_at.strftime("%H:%M"),
        "scannedAtIso": scanned_at.isoformat(),
        "start": start.isoformat(),
        "collected": len(raw),
        "selected": len(selected),
        "events": selected,
        "sources": statuses,
        "serviceHealth": service_health,
        "durationSeconds": round(total_seconds, 1),
        "timings": {
            "sources": round(collection_seconds, 1),
            "analysis": round(analysis_seconds, 1),
            "stocks": round(market_seconds, 1),
        },
        "ranked": len(market_events),
        "excludedOverLimit": max(0, len(market_events) - duplicate_companies - len(selected)),
        "excludedCompanyDuplicates": duplicate_companies,
        "warnings": errors[:8],
    }


class LocalHandler(SimpleHTTPRequestHandler):
    server_version = "MarketCatch/2.0.2"

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, fmt: str, *args: Any) -> None:
        path = str(args[0]) if args else ""
        if "/api/" in path:
            return
        super().log_message(fmt, *args)

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()

    def json_response(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path == "/api/health":
            self.json_response(200, {"ok": True, "mode": "app", "version": "2.0.2"})
            return
        if self.path in {"", "/"}:
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self) -> None:
        host = self.headers.get("Host", "")
        if not (host.startswith("127.0.0.1:") or host.startswith("localhost:")):
            self.json_response(403, {"ok": False, "error": "로컬 요청만 허용됩니다"})
            return
        origin = self.headers.get("Origin")
        if origin and origin not in ALLOWED_ORIGINS:
            self.json_response(403, {"ok": False, "error": "허용되지 않은 요청 출처입니다"})
            return
        if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json":
            self.json_response(415, {"ok": False, "error": "JSON 요청만 허용됩니다"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            self.json_response(413, {"ok": False, "error": "요청 크기가 올바르지 않습니다"})
            return
        try:
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(body, dict):
                raise ValueError
            if self.path == "/api/test":
                result = test_source(body)
            elif self.path == "/api/scan":
                result = run_scan(body)
            else:
                self.json_response(404, {"ok": False, "error": "없는 API 주소입니다"})
                return
            self.json_response(200, {"ok": True, **result})
        except ApiProblem as error:
            self.json_response(error.status, {"ok": False, "error": str(error)})
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            self.json_response(400, {"ok": False, "error": "요청 형식을 읽지 못했습니다"})
        except Exception as error:  # Keep secrets out of the response and terminal.
            self.json_response(500, {"ok": False, "error": f"로컬 앱 오류: {type(error).__name__}"})


_ANDROID_SERVER: ThreadingHTTPServer | None = None


def start_android_server(static_dir: str, port: int = DEFAULT_PORT) -> str:
    """Start the private loopback server used by the Android WebView.

    The HTML is copied from the APK assets into the app's private files
    directory by MainActivity before this function is called.
    """
    global STATIC_DIR, _ANDROID_SERVER
    STATIC_DIR = Path(static_dir).resolve()
    if _ANDROID_SERVER is not None:
        return f"http://{HOST}:{port}"
    _ANDROID_SERVER = ThreadingHTTPServer((HOST, int(port)), LocalHandler)
    thread = threading.Thread(target=_ANDROID_SERVER.serve_forever, name="market-catch-api", daemon=True)
    thread.start()
    return f"http://{HOST}:{port}"


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_PORT
    server = ThreadingHTTPServer((HOST, port), LocalHandler)
    print(f"Market Catch local app: http://{HOST}:{port}", flush=True)
    print("API keys may be saved in this browser; the server does not write them to disk.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
