package com.marketcatch.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String LOG_TAG = "MarketCatch";
    private static final String LOCAL_HOST = "127.0.0.1";
    private static final String LOCAL_URL = "http://127.0.0.1:4173/";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(242, 245, 247));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        try {
            File webRoot = new File(getFilesDir(), "web-v1");
            if (!webRoot.exists() && !webRoot.mkdirs()) {
                throw new IOException("앱 화면 폴더를 만들 수 없습니다");
            }
            copyAsset("index.html", new File(webRoot, "index.html"));
            PyObject module = Python.getInstance().getModule("local_app");
            module.callAttr("start_android_server", webRoot.getAbsolutePath(), 4173);
            showWebView();
        } catch (Exception error) {
            Log.e(LOG_TAG, "App startup failed", error);
            TextView message = new TextView(this);
            message.setPadding(32, 64, 32, 32);
            message.setTextSize(18);
            message.setTextColor(Color.rgb(20, 33, 44));
            String detail = error.getMessage();
            if (detail == null || detail.trim().isEmpty()) {
                detail = error.toString();
            }
            message.setText("앱을 시작하지 못했습니다.\n\n" + detail);
            setContentView(message);
        }
    }

    private void copyAsset(String assetName, File target) throws IOException {
        try (InputStream input = getAssets().open(assetName);
             FileOutputStream output = new FileOutputStream(target, false)) {
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
        }
    }

    private void showWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(242, 245, 247));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUserAgentString(settings.getUserAgentString() + " MarketCatch/2.0.2");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }
        });
        setContentView(webView);
        webView.loadUrl(LOCAL_URL);
    }

    private boolean openExternalIfNeeded(Uri uri) {
        if ("http".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost())) {
            return false;
        }
        if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
