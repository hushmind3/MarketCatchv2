# Version 1 keeps minification disabled so Python/Java bridge names remain clear.
