# 놓친 소식 찾기 v2.0.0

개인용 한국 주식 뉴스·공시 스캐너의 Android 버전입니다. 자동 알림이나 주문 기능은 없고, 사용자가 버튼을 누를 때만 검색합니다.

## APK 설치

`Market-Catch-v2.apk`를 64비트 Android 휴대폰(Android 7.0 이상)으로 옮긴 뒤 설치합니다. 처음 설치할 때 Android가 출처를 확인하면 해당 파일 설치를 허용하세요.

현재 APK는 개인 설치용 디버그 서명본입니다. Play 스토어 배포용은 본인 릴리스 키로 다시 서명해야 합니다.

v1 위에 v2를 업데이트 설치할 수 있도록 앱 패키지 ID는 `com.marketcatch.v1`을 그대로 유지했습니다. 앱을 삭제하거나 앱 데이터를 지우지 않고 업데이트 설치하면 기존 앱에 저장한 API 키와 설정이 유지됩니다.

## 앱에서 입력하는 키

- NAVER API HUB 뉴스 검색 Client ID / Client Secret
- OpenDART 인증키
- 한국투자증권 App Key / App Secret (시세 조회용, 선택)
- Finnhub API Key (무료 외신 보조 검색, 선택)
- GNews 또는 NewsAPI 키 (선택)
- OpenAI API Key (관련 종목 추론 보조용, 선택)

API 키는 Android WebView의 앱 전용 저장공간에 저장합니다. APK, 서버 파일, GitHub 소스에는 키를 넣지 않습니다. 앱 삭제 또는 앱 데이터 초기화를 하면 저장된 키도 사라집니다. 주문 API는 구현하지 않았습니다.

## v2 핵심 기능

- 전체 시장 스캔과 키워드 검색을 별도 탭으로 제공
- KOSPI, KOSDAQ을 선택해서 검색
- OpenDART 공시와 NAVER·선택한 해외 뉴스 검색
- 호재와 악재를 나눠 각각 최대 30건 표시
- 최초 공개부터 사용자가 검색한 시점까지의 시간과 가격 변화 표시
- 직접 언급 종목뿐 아니라 업종·공급망 관련 종목도 함께 표시

## GitHub에서 APK 만들기

1. 이 폴더 내용을 새 GitHub 저장소에 올립니다.
2. GitHub의 `Actions` 탭에서 `Build Android APK`를 실행합니다.
3. 작업이 끝나면 `market-catch-v2-apk` 파일을 내려받습니다.

로컬 빌드는 JDK 17, Android SDK 34, Python 3.12가 필요합니다.

```bash
./gradlew assembleDebug -PbuildPython="$(command -v python3.12)"
```

생성 위치: `app/build/outputs/apk/debug/app-debug.apk`
